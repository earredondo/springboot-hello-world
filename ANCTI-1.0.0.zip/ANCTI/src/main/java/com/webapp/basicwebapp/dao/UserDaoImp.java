/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webapp.basicwebapp.dao;

/**
 *
 * @author edgar
 */
import com.webapp.basicwebapp.modelo.User;
import com.webapp.basicwebapp.pojos.UserTbl;
import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class UserDaoImp implements UserDao {

   @Autowired
   private SessionFactory sessionFactory;

   @Override
   public void save(UserTbl user) {
      sessionFactory.getCurrentSession().save(user);
   }

   @Override
   public List<UserTbl> list() {
      @SuppressWarnings("unchecked")
      TypedQuery<UserTbl> query = sessionFactory.getCurrentSession().createQuery("from User");
      return query.getResultList();
   }

}