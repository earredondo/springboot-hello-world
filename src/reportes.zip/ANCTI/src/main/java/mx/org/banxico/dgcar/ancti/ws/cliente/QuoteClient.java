/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.ws.cliente;

import mx.org.banxico.dgcar.ancti.ws.GetNotificacionRequest;
import mx.org.banxico.dgcar.ancti.ws.GetNotificacionResponse;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.core.SoapActionCallback;

/**
 *
 * @author T42719
 */
public class QuoteClient extends WebServiceGatewaySupport {
    
    /**
     *
     * @param id
     * @return
     */
    public GetNotificacionResponse getQuote(Long id){
        GetNotificacionRequest request = new GetNotificacionRequest();
        request.setId(id);
        
        GetNotificacionResponse response = (GetNotificacionResponse) getWebServiceTemplate()
                .marshalSendAndReceive("http://localhost:8080/ANCTI/ws/", request, new SoapActionCallback("http://spring.io/guides/gs-producing-web-service/getNotificacionRequest"));
        return response;
    }
            
}
