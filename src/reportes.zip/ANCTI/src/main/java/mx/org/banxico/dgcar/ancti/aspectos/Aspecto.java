/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.aspectos;

import mx.org.banxico.dgcar.ancti.dao.BitacoraDao;
import java.util.Date;
import mx.org.banxico.dgcar.ancti.pojos.Bitacora;
import mx.org.banxico.dgcar.ancti.seguridad.AuthenticationFacade;
import mx.org.banxico.dgcar.ancti.seguridad.BanxicoAuthenticationToken;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.banxico.ds.security.Principal;
import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author T42719
 */
@Aspect
public class Aspecto {
    
    @Autowired(required = true)
    private BitacoraDao bitacoraDao;
    
    @Autowired
    private AuthenticationFacade authenticationFacade;
    
    private static Logger loggerExceptions = LogManager.getLogger(Aspecto.class);
    
    /**
     *
     * @param pp
     * @return
     * @throws Throwable
     */
    @Around("@annotation(mx.org.banxico.dgcar.ancti.aspectos.Loggable)")
    public Object crearBitacoraServicios(ProceedingJoinPoint pp) throws Throwable{
        
        BanxicoAuthenticationToken authentication = (BanxicoAuthenticationToken)authenticationFacade.getAuthentication();
        String usuario = authentication == null ? "app test" : ((Principal)authentication.getPrincipal()).getUserName();
        Bitacora bitacora = new Bitacora();
        bitacora.setUsuario(usuario);
        bitacora.setAccion(pp.getSignature().toString());
        bitacora.setArgumentos(pp.getArgs().length > 0 ? pp.getArgs()[0].toString() : "");
        bitacora.setFecha(new Date());
        
        try {
            Object resultado = pp.proceed();
            bitacora.setResultado("OK");
            try{
                bitacoraDao.create(bitacora);
            }catch(HibernateException he){
                bitacoraDao.recreate(bitacora);
            }
            return resultado;
        }
        catch(Throwable e) {
            bitacora.setResultado(e.getMessage());
            loggerExceptions.error("\n" + bitacora + "\n");
            throw e;
        }
    }
    
}
