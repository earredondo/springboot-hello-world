/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.dao;

import java.util.List;
import mx.org.banxico.dgcar.ancti.pojos.Rol;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

/**
 *
 * @author T42719
 */
@Repository
public class RolDaoImp extends GenericDaoImp<Rol, Long> implements RolDao{
    
    /**
     *
     * @return
     */
    public Session openSession() {
        return super.sessionFactory().openSession();
    }
    
    /**
     *
     * @param groupName
     * @return
     */
    @Override
    public Rol findByGroup(String groupName){
        try (Session sesion = openSession()) {
            List<Rol> roles = sesion.createQuery("select rol from Rol rol, GruposDeControl grupo where lower(grupo.nombre) = lower('" + groupName + "') and rol.idRol = grupo.rol.idRol").list();
            return roles.isEmpty() ? null : roles.get(0);
        }
    }
}
