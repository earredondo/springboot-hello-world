/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.presentacion;

import mx.org.banxico.dgcar.ancti.pojos.GruposDeControl;
import mx.org.banxico.dgcar.ancti.servicios.GruposDeControlService;
import java.io.Serializable;
import java.util.Enumeration;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import mx.org.banxico.dgcar.ancti.pojos.Rol;
import mx.org.banxico.dgcar.ancti.servicios.RolService;
import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.primefaces.context.RequestContext;
import org.primefaces.event.RowEditEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 *
 * @author T42719
 */
@Scope(value = "session")
@Component(value = "grupoAdmin")
@ELBeanName(value = "grupoAdmin")
@Join(path = "/controlacceso", to = "/ControlDeAcceso.jsf")
public class ControladorAdministradores implements Serializable{
    
    @Autowired(required = true)
    private GruposDeControlService grupoService;
    
    @Autowired(required = true)
    private RolService rolService;
    
    private List<GruposDeControl> grupos;
    private GruposDeControl administrador;
    private List<Rol> roles;
    
    /**
     *
     */
    @PostConstruct
    public void init(){
        this.administrador = new GruposDeControl();
    }

    /**
     *
     * @return
     */
    public List<GruposDeControl> getGrupos() {return this.grupos == null ? this.grupos = grupoService.getAll() : this.grupos;}

    /**
     *
     * @param grupos
     */
    public void setGrupos(List<GruposDeControl> grupos) {this.grupos = grupos;}
    
    /**
     *
     */
    public void registrarAdministrador(){
        try{
            GruposDeControl nuevoAdministrador = new GruposDeControl(this.administrador);
            grupoService.create(nuevoAdministrador);
            grupos.add(nuevoAdministrador);
            RequestContext.getCurrentInstance().execute("PF('modalRegistrarAdministrador').hide()");
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro exitoso", this.administrador.getNombre()));
            this.administrador = new GruposDeControl();
        }catch(Exception e){
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", this.administrador.getNombre() + " ya existe como administrador."));
        }
    }
    
    /**
     *
     * @param grupo
     */
    public void eliminarGrupo(GruposDeControl grupo){
        grupoService.remove(grupo);
        grupos.remove(grupo);
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro eliminado", grupo.getNombre()));
    }

    /**
     * @return the administrador
     */
    public GruposDeControl getAdministrador() {
        return administrador;
    }

    /**
     * @param administrador the administrador to set
     */
    public void setAdministrador(GruposDeControl administrador) {
        this.administrador = administrador;
    }
    
    /**
     * @return the roles
     */
    public List<Rol> getRoles() {
        return this.rolService.getAll();
    }

    /**
     * @param roles the roles to set
     */
    public void setRoles(List<Rol> roles) {
        this.roles = roles;
    }
    
    /**
     *
     * @param event
     */
    public void onRowEdit(RowEditEvent event) {
        FacesMessage msg;
        GruposDeControl grupoActualizado = (GruposDeControl) event.getObject();
        try{
            this.grupoService.saveOrUpdate(grupoActualizado);
            msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Grupo editado", ((GruposDeControl) event.getObject()).getNombre());
        }catch(Exception e){
            grupoActualizado.setNombre(this.administrador.getNombre());
            grupoActualizado.setRol(this.administrador.getRol());
            msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Ya existe un registro con el nombre " + ((GruposDeControl) event.getObject()).getNombre());
        }
        FacesContext.getCurrentInstance().addMessage(null, msg);
    }
     
    /**
     *
     * @param event
     */
    public void onRowCancel(RowEditEvent event) {
        FacesMessage msg = new FacesMessage("Edición Cancelada", ((GruposDeControl) event.getObject()).getNombre());
        FacesContext.getCurrentInstance().addMessage(null, msg);
    }
    
    /**
     *
     * @param event
     */
    public void onRowEditInit(RowEditEvent event) {
        GruposDeControl grupoOriginal = (GruposDeControl) event.getObject();
        this.administrador = new GruposDeControl(grupoOriginal);
    }

}
