/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.config;

/**
 *
 * @author edgar
 */
import java.util.Properties;
import mx.org.banxico.dgcar.ancti.aspectos.Aspecto;
import mx.org.banxico.dgcar.ancti.utils.FSM;
import mx.org.banxico.dgcar.ancti.ws.cliente.QuoteClient;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

/**
 *
 * @author T42719
 */
@Configuration
@EnableAspectJAutoProxy
@EnableTransactionManagement
@ComponentScans(value = {
    @ComponentScan("mx.org.banxico.dgcar.ancti.dao"),
    @ComponentScan("mx.org.banxico.dgcar.ancti.servicios"),
    @ComponentScan("mx.org.banxico.dgcar.ancti.presentacion"),
    @ComponentScan("mx.org.banxico.dgcar.ancti.seguridad"),
    @ComponentScan("mx.org.banxico.dgcar.ancti.utils")})
public class AppConfig {

    /**
     *
     * @return
     */
    @Bean
    public LocalSessionFactoryBean getSessionFactory() {
        LocalSessionFactoryBean factoryBean = new LocalSessionFactoryBean();
        factoryBean.setConfigLocation(new ClassPathResource("hibernate.cfg.xml"));
        return factoryBean;
    }

    /**
     *
     * @return
     */
    @Bean
    public HibernateTransactionManager getTransactionManager() {
        HibernateTransactionManager transactionManager = new HibernateTransactionManager();
        transactionManager.setSessionFactory(getSessionFactory().getObject());
        return transactionManager;
    }

    /**
     *
     * @return
     */
    @Bean
    public Aspecto getAspecto() {
        return new Aspecto();
    }
    
    /**
     *
     * @return
     */
    @Bean
    public JavaMailSender getJavaMailSender() {
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        
        mailSender.setHost("BMMAIL");
        mailSender.setPort(25);
        mailSender.setProtocol("smtp");
        mailSender.setUsername("ancti@banxico.org.mx");
        
        Properties props = mailSender.getJavaMailProperties();
        props.put("mail.debug", "true");

        return mailSender;
    }
    
    /**
     *
     * @return
     */
    @Bean
    public Jaxb2Marshaller marshaller(){
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPath("mx.org.banxico.dgcar.ancti.ws");
        return marshaller;
    }
    
    /**
     *
     * @param marshaller
     * @return
     */
    @Bean
    public QuoteClient quoteClient(Jaxb2Marshaller marshaller) {
            QuoteClient client = new QuoteClient();
            client.setDefaultUri("http://localhost:8080/ANCTI/ws/");
            client.setMarshaller(marshaller);
            client.setUnmarshaller(marshaller);
            //client.setMessageSender(messageSender);
            return client;
    }
    
    /*En caso de que se requiera autenticacion en el servicio web */
    /*
    @Bean
    public WebServiceMessageSender messageSender(Credentials credentials) throws Exception{
        HttpComponentsMessageSender messageSender = new HttpComponentsMessageSender();
        messageSender.setCredentials(credentials);
        return messageSender;
    }

    @Bean
    public Credentials credentials(){
        UsernamePasswordCredentials credentials = new UsernamePasswordCredentials("usuario", "password");
        return credentials;

    }
    */

    /**
     *
     * @return
     */
    
    
    @Bean
    public FSM getFSM(){
        String[] estados            = {"Borrador", "Por enviar", "Enviada", "Cancelada"};
        String[] transiciones       = {"Solicitar aprobación", "Solicitar correciones", "Enviar", "Cancelar"};
        
        String rolAdministrador     = "ROLE_Administrador";
        String rolColaborador       = "ROLE_Colaborador";
        String[][] autorizaciones   = {{rolAdministrador, rolColaborador}, {rolAdministrador}, {rolAdministrador}, {rolAdministrador}};
        
        int[][] tablaDeTransiciones = { { 1, -1, -1, -1},
                                        {-1,  0,  2, -1},
                                        {-1, -1, -1,  3},
                                        {-1, -1, -1, -1}
                                      };
        return new FSM(tablaDeTransiciones, 0, estados, transiciones, autorizaciones);
    }

}
