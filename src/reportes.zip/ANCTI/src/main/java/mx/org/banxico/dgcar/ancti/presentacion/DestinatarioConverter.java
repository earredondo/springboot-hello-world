/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.presentacion;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import mx.org.banxico.dgcar.ancti.pojos.Destinatario;
import mx.org.banxico.dgcar.ancti.servicios.DestinatarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 *
 * @author T42719
 */
@Component(value = "destinatarioConverter")
public class DestinatarioConverter implements Converter {
    
    @Autowired(required = true)
    private DestinatarioService service;
 
    /**
     *
     * @param fc
     * @param uic
     * @param value
     * @return
     */
    @Override
    public Object getAsObject(FacesContext fc, UIComponent uic, String value) {
        if(value != null && value.trim().length() > 0) {
            try {
                for(Destinatario destinatario : service.getAll()){
                    if (value.equals(destinatario.getCorreo())) {
                        return destinatario;
                    }
                }
                return null;
            } catch(Exception e) {
                throw new ConverterException(new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error de conversión", "No es un destinatario válido."));
            }
        }
        else {
            return null;
        }
    }
 
    /**
     *
     * @param fc
     * @param uic
     * @param object
     * @return
     */
    @Override
    public String getAsString(FacesContext fc, UIComponent uic, Object object) {
        if(object != null) {
            return String.valueOf(((Destinatario) object).getCorreo());
        }
        else {
            return null;
        }
    }   
}     