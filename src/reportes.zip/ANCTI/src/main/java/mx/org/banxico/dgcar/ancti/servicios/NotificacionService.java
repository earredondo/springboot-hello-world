/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.servicios;

import java.util.List;
import javax.mail.internet.AddressException;
import mx.org.banxico.dgcar.ancti.pojos.Notificacion;
import mx.org.banxico.dgcar.ancti.pojos.TipoPlantilla;
import org.primefaces.model.UploadedFile;
import org.springframework.mail.MailException;

/**
 *
 * @author edgar
 */
public interface NotificacionService extends GenericService<Notificacion,Long>{

    /**
     *
     * @param file
     * @param jasper
     * @return
     */
    public List<Notificacion> importarNotificacionesExcel(UploadedFile file, TipoPlantilla jasper);

    /**
     *
     * @param notificacion
     * @return
     */
    public String vistaPrevia(Notificacion notificacion);

    /**
     *
     * @param notificaciones
     * @return
     */
    public String vistaPrevia(List<Notificacion> notificaciones);

    /**
     *
     * @param notificacion
     * @param contenido
     * @throws MailException
     * @throws AddressException
     */
    public void sendEmail(Notificacion notificacion, String contenido) throws MailException, AddressException;

    /**
     *
     * @param notificacion
     */
    public void cancelarNotificacion(Notificacion notificacion);

    /**
     *
     * @param notificacion
     * @return
     */
    public List<String> getTransicionesDisponibles(Notificacion notificacion);

    /**
     *
     * @param notificaciones
     * @param transicion
     */
    public void cambiarEstado(List<Notificacion> notificaciones, String transicion);

    /**
     *
     */
    public void cerrarSesion();
}
