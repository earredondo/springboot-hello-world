/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.servicios;

import mx.org.banxico.dgcar.ancti.dao.DestinatarioNotificacionDao;
import mx.org.banxico.dgcar.ancti.dao.GenericDao;
import mx.org.banxico.dgcar.ancti.pojos.DestinatarioNotificacion;
import mx.org.banxico.dgcar.ancti.pojos.DestinatarioNotificacionId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 *
 * @author edgar
 */
@Service
public class DestinatarioNotificacionServiceImp extends GenericServiceImp<DestinatarioNotificacion, DestinatarioNotificacionId>
        implements DestinatarioNotificacionService {
   
    private DestinatarioNotificacionDao destinatarioNotificacionDao;

    /**
     *
     */
    public DestinatarioNotificacionServiceImp(){
 
    }

    /**
     *
     * @param genericDao
     */
    @Autowired
    public DestinatarioNotificacionServiceImp(
            @Qualifier("destinatarioNotificacionDaoImp") GenericDao<DestinatarioNotificacion, DestinatarioNotificacionId> genericDao) {
        super(genericDao);
        this.destinatarioNotificacionDao = (DestinatarioNotificacionDao) genericDao;
    }
}