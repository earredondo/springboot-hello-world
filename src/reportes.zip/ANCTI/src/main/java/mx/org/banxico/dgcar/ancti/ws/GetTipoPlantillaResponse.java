/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.ws;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import mx.org.banxico.dgcar.ancti.pojos.TipoPlantilla;

/**
 *
 * @author T42719
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "tipoPlantillas"
})
@XmlRootElement(name = "getTipoPlantillaResponse")
public class GetTipoPlantillaResponse {
    
    /**
     *
     */
    @XmlElement(required = true)
    protected List<TipoPlantilla> tipoPlantillas;

    /**
     *
     * @return
     */
    public List<TipoPlantilla> getTipoPlantilla() {
        return tipoPlantillas;
    }

    /**
     *
     * @param value
     */
    public void setTipoPlantilla(List<TipoPlantilla> value) {
        this.tipoPlantillas = value;
    }
}
