/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.seguridad;

import org.springframework.security.core.Authentication;

/**
 *
 * @author T42719
 */
public interface AuthenticationFacade {

    /**
     *
     * @return
     */
    public Authentication getAuthentication();

    /**
     *
     * @param authentication
     */
    public void setAuthentication(Authentication authentication);
}
