/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.servicios;

import java.io.InputStream;
import mx.org.banxico.dgcar.ancti.aspectos.Loggable;
import mx.org.banxico.dgcar.ancti.dao.TipoPlantillaDao;
import mx.org.banxico.dgcar.ancti.dao.GenericDao;
import mx.org.banxico.dgcar.ancti.pojos.TipoPlantilla;
import mx.org.banxico.dgcar.ancti.utils.ExcelReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author edgar
 */
@Service
public class TipoPlantillaServiceImp extends GenericServiceImp<TipoPlantilla, Long>
        implements TipoPlantillaService {
   
    private TipoPlantillaDao plantillaDao;
    
    @Autowired(required = true)
    private ExcelReader excelReader;

    /**
     *
     */
    public TipoPlantillaServiceImp(){
 
    }

    /**
     *
     * @param genericDao
     */
    @Autowired
    public TipoPlantillaServiceImp(
             /*@Qualifier("admininstradorSistemaDaoImp") */GenericDao<TipoPlantilla, Long> genericDao) {
        super(genericDao);
        this.plantillaDao = (TipoPlantillaDao) genericDao;
    }

    /**
     *
     * @param name
     * @return
     */
    @Override
    @Loggable
    @Transactional(propagation = Propagation.REQUIRED)
    public TipoPlantilla findByName(String name) {
        return this.plantillaDao.findByNaturalId(name);
    }
    
    /**
     *
     * @param excel
     * @param jasper
     * @return
     */
    @Override
    public InputStream agregarMetadatos(TipoPlantilla excel, TipoPlantilla jasper){
        return this.excelReader.agregarMetadatos(excel, jasper);
    }

}