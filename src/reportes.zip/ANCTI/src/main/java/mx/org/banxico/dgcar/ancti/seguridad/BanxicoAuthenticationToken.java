/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.seguridad;

import java.util.Collection;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

/**
 *
 * @author T42719
 */
public class BanxicoAuthenticationToken extends AbstractAuthenticationToken{

    private final Object principal;
    
    /**
     *
     * @param principal
     * @param authorities
     */
    public BanxicoAuthenticationToken(Object principal, Collection<? extends GrantedAuthority> authorities) {
        super(authorities);
        this.principal = principal;
        super.setAuthenticated(true);
    }
    
    /**
     *
     * @return
     */
    @Override
    public Object getCredentials() {
        return null;
    }

    /**
     *
     * @return
     */
    @Override
    public Object getPrincipal() {
        return this.principal;
    }
    
}
