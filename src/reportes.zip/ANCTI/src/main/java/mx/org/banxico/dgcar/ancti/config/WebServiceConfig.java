/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.ws.config.annotation.EnableWs;
import org.springframework.ws.config.annotation.WsConfigurerAdapter;
import org.springframework.ws.wsdl.wsdl11.DefaultWsdl11Definition;
import org.springframework.xml.xsd.XsdSchemaCollection;
import org.springframework.xml.xsd.commons.CommonsXsdSchemaCollection;

/**
 *
 * @author T42719
 */

@EnableWs
@Configuration
@ComponentScans(value = {
    @ComponentScan("mx.org.banxico.dgcar.ancti.ws")})
public class WebServiceConfig extends WsConfigurerAdapter{

    /**
     *
     * @param notificacionesSchema
     * @return
     */
    @Bean(name = "notificaciones")
    public DefaultWsdl11Definition defaultWsdl11Definition(XsdSchemaCollection notificacionesSchema) {
            DefaultWsdl11Definition wsdl11Definition = new DefaultWsdl11Definition();
            wsdl11Definition.setPortTypeName("notificacionesPort");
            wsdl11Definition.setLocationUri("/ws");
            wsdl11Definition.setTargetNamespace("http://spring.io/guides/gs-producing-web-service");
            wsdl11Definition.setSchemaCollection(notificacionesSchema);
            return wsdl11Definition;
    }

    /**
     *
     * @return
     */
    @Bean
    public XsdSchemaCollection notificacionesSchema() {
            CommonsXsdSchemaCollection xsd= new CommonsXsdSchemaCollection(new ClassPathResource("schema1.xsd"));
            xsd.setInline(true);
            return xsd;
    }

}
