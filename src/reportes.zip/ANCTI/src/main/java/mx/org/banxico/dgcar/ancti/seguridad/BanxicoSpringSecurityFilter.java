/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.seguridad;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import javax.servlet.FilterChain;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import mx.org.banxico.dgcar.ancti.pojos.Rol;
import mx.org.banxico.dgcar.ancti.servicios.RolService;
import org.banxico.ds.digest.DigestSSPServer;
import org.banxico.ds.ntlm.NTLMSSPServer;
import org.banxico.ds.sasl.SaslServer;
import org.banxico.ds.security.Group;
import org.banxico.ds.security.Principal;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 *
 * @author T42719
 */
public class BanxicoSpringSecurityFilter extends OncePerRequestFilter{

    private HttpSession httpSession;
    private RolService rolService;
    
    /**
     *
     * @param hsr
     * @param hsr1
     * @param fc
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doFilterInternal(HttpServletRequest hsr, HttpServletResponse hsr1, FilterChain fc) throws ServletException, IOException {
        if(this.rolService == null){
            ServletContext servletContext = hsr.getServletContext();
            WebApplicationContext webApplicationContext = WebApplicationContextUtils.getWebApplicationContext(servletContext);
            this.rolService = webApplicationContext.getBean(RolService.class);

        }
        final Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if(authentication == null) {

            httpSession = hsr.getSession(true);
            Principal principal = getPrincipal();
            BanxicoAuthenticationToken banxicoAuthentication = new BanxicoAuthenticationToken(principal, getAuthorities(principal));
            SecurityContextHolder.getContext().setAuthentication(banxicoAuthentication);
        }
        
        fc.doFilter(hsr, hsr1);
    }
    
    private Principal getPrincipal(){
        
        Object object = httpSession.getAttribute("org.banxico.ds.saabm.fs.secctxt");
        
        if(object == null) { return new Principal("anonymous", null); }
        
        //DigestSSPServer dg = (DigestSSPServer)object;
        //NTLMSSPServer dg = (NTLMSSPServer)object;
        SaslServer dg = (SaslServer) object;
        Principal pr = dg.getAuthorizationPrincipal();

        return pr;
    }
    
    private List<SimpleGrantedAuthority> getAuthorities(Principal principal){
        Collection<Rol> roles = new HashSet<>();
        if(principal.getUserName().equals("anonymous")){
            roles.add(new Rol(0, "anonymus", null));
        }else{
            Group[] gruposAd = principal.getGroups();
            Rol rol;
            for(Group grupoAd : gruposAd){
                rol = this.rolService.findByGroupName(grupoAd.getDisplayName().split("@")[0]);
                if(rol != null){ roles.add(rol); }
            }
            rol = this.rolService.findByGroupName(principal.getUserName());
            if(rol != null){ roles.add(rol); }
        }
        
        List<SimpleGrantedAuthority> authorities = new ArrayList<>();
        for(Rol rol : roles){
            authorities.add(new SimpleGrantedAuthority("ROLE_" + rol.getNombre()));
        }
        return authorities;
    }
    
}
