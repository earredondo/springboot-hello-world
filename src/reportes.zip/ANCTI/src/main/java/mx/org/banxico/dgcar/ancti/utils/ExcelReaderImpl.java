/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import mx.org.banxico.dgcar.ancti.pojos.Destinatario;
import mx.org.banxico.dgcar.ancti.pojos.Estado;
import mx.org.banxico.dgcar.ancti.pojos.Metadato;
import mx.org.banxico.dgcar.ancti.pojos.Notificacion;
import mx.org.banxico.dgcar.ancti.pojos.Plantilla;
import mx.org.banxico.dgcar.ancti.pojos.TipoMetadato;
import mx.org.banxico.dgcar.ancti.pojos.TipoPlantilla;
import mx.org.banxico.dgcar.ancti.servicios.EstadoService;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 *
 * @author T42719
 */

@Component
public class ExcelReaderImpl implements ExcelReader<Notificacion> {
    
    @Autowired(required = true)
    private EstadoService estadoService;
    
    private Object getCellValue(Cell cell){
        switch(cell.getCellTypeEnum()){
            case STRING:
                return cell.getStringCellValue();
            case BOOLEAN:
                return cell.getBooleanCellValue();
            case NUMERIC:
                return cell.getNumericCellValue();
        }
        return null;
    }
    
    /**
     *
     * @param fileName
     * @param stream
     * @param jasper
     * @return
     */
    @Override
    public List readObjects(String fileName, InputStream stream, TipoPlantilla jasper){
        List<Notificacion> notificaciones = new ArrayList();
        Workbook workbook = null;
        
        try{
            workbook = getWorkbook(stream, fileName);
        }catch(IOException ioe){
            ioe.printStackTrace();
            return null;
        }
        
        Sheet hoja = workbook.getSheetAt(0);
        Row headers = hoja.getRow(0);
        Iterator<Row> iterator = hoja.iterator();
        
        if(!checkHeaders(iterator))return null;
        
        rowloop:
        while(iterator.hasNext()){
            Row nextRow = iterator.next();
            Iterator<Cell> cellIterator = nextRow.iterator();
            
            Plantilla plantilla = new Plantilla();
            Notificacion notificacion = new Notificacion();
            List<Destinatario> destinatarios = new ArrayList();
            List<Destinatario> copiasPara = new ArrayList();
            Set<Metadato> metadatos = new LinkedHashSet();
            String[] titulos, nombres, correos;
            
            while(cellIterator.hasNext()){
                Cell nextCell = cellIterator.next();
                int columna = nextCell.getColumnIndex();
                int i;
                if(columna < 6){
                    switch(columna){
                        case 0:
                            notificacion.setAsunto((String)getCellValue(nextCell));
                            break;
                        case 1:
                            titulos = ((String)getCellValue(nextCell)).split(",");
                            for(String titulo : titulos){
                                Destinatario destinatario = new Destinatario();
                                destinatario.setGradoAcademico(titulo.trim());
                                destinatarios.add(destinatario);
                            }
                            break;
                        case 2:
                            nombres = ((String)getCellValue(nextCell)).split(",");
                            i = 0;
                            for(String nombre : nombres){
                                destinatarios.get(i++).setNombre(nombre.trim());
                            }
                            break;
                        case 3:
                            correos = ((String)getCellValue(nextCell)).split(",");
                            i = 0;
                            for(String correo : correos){
                                destinatarios.get(i++).setCorreo(correo.trim());
                            }
                            break;
                        case 4:
                            nombres = ((String)getCellValue(nextCell)).split(",");
                            for(String nombre : nombres){
                                Destinatario destinatario = new Destinatario();
                                destinatario.setNombre(nombre.trim());
                                copiasPara.add(destinatario);
                            }
                            break;
                        case 5:
                            correos = ((String)getCellValue(nextCell)).split(",");
                            i = 0;
                            for(String correo : correos){
                                copiasPara.get(i++).setCorreo(correo.trim());
                            }
                            break;
                    }
                }else{
                    String nombreMetadato = headers.getCell(columna).getStringCellValue();
                    String valor = (String)getCellValue(nextCell);
                    Metadato metadato = new Metadato();
                    for(TipoMetadato tm : jasper.getTipoMetadatos()){
                        if(tm.getNombre().equalsIgnoreCase(nombreMetadato)){ 
                            metadato.setTipoMetadato(tm);
                            metadato.setValor(valor);
                            metadato.setPlantilla(plantilla);
                        }
                    }
                    metadatos.add(metadato);
                }
            }
            
            plantilla.setNotificacion(notificacion);
            plantilla.setMetadatos(metadatos);
            plantilla.setTipoPlantilla(jasper);
            
            notificacion.getPlantillas().add(plantilla);
            notificacion.addAllDestinatarios(destinatarios, "destinatario");
            notificacion.addAllDestinatarios(copiasPara, "con copia");
            
            Estado borrador = this.estadoService.findByName("Borrador");
            if(borrador == null){
                borrador = new Estado();
                borrador.setNombre("Borrador");
                this.estadoService.create(borrador);
            }
            notificacion.setEstado(borrador);
            
            notificaciones.add(notificacion);
        }
        return notificaciones;
    }

    /**
     *
     * @param filePath
     * @param jasper
     * @return
     */
    @Override
    public List readObjects(String filePath, TipoPlantilla jasper) {
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(new File(filePath));
        } catch (IOException ioe) {
            ioe.printStackTrace();
            return null;
        }
        return readObjects(filePath, fis, jasper);
    }
    
    private Workbook getWorkbook(InputStream fis, String filePath) throws IOException{
        Workbook workbook = null;
        if(filePath.endsWith("xlsx")){
            workbook = new XSSFWorkbook(fis);
        }else if(filePath.endsWith("xls")){
            workbook = new HSSFWorkbook(fis);
        }else{
            throw new IllegalArgumentException("El archivo especificado no es un arhcivo de Excel.");
        }
        return workbook;
    }
    
    private boolean checkHeaders(Iterator<Row> iterator){
        if(!iterator.hasNext())return false;
        Row nextRow = iterator.next();
        Iterator<Cell> itera = nextRow.iterator();
        while(itera.hasNext()){
            Cell nextCell = itera.next();
            int columna = nextCell.getColumnIndex();
            switch(columna){
                case 0:
                    if(!"Asunto".equalsIgnoreCase((String)getCellValue(nextCell))) return false;
                    break;
                case 1:
                    if(!"TítuloDest".equalsIgnoreCase((String)getCellValue(nextCell))) return false;
                    break;   
                case 2:
                    if(!"Destinatario".equalsIgnoreCase((String)getCellValue(nextCell))) return false;
                    break;
                case 3:
                    if(!"Email".equalsIgnoreCase((String)getCellValue(nextCell))) return false;
                    break;
                case 4:
                    if(!"Con copia para".equalsIgnoreCase((String)getCellValue(nextCell))) return false;
                    break;
                case 5:
                    if(!"Email".equalsIgnoreCase((String)getCellValue(nextCell))) return false;
                    return true;
            }
        }
        return true;
    }
    
    /**
     *
     * @param excel
     * @param jasper
     * @return
     */
    @Override
    public InputStream agregarMetadatos(TipoPlantilla excel, TipoPlantilla jasper){
        InputStream stream = new ByteArrayInputStream(excel.getContenido());
        String fileName = excel.getNombre();
        Workbook workbook = null;
        
        try{
            workbook = getWorkbook(stream, fileName);
        }catch(IOException ioe){
            ioe.printStackTrace();
            return null;
        }
        
        Sheet hoja = workbook.getSheetAt(0);
        Iterator<Row> iterator = hoja.iterator();
        
        if(!checkHeaders(iterator))return null;
        
        Row headers = hoja.getRow(0);
        
        int index = 6;
        
        for(TipoMetadato metadato : jasper.getTipoMetadatos()){
            Cell cell = headers.createCell(index++);
            cell.setCellValue(metadato.getNombre());
        }
        
        try{
            ByteArrayOutputStream result = new ByteArrayOutputStream();
            workbook.write(result);
            return new ByteArrayInputStream(result.toByteArray());
        }catch(IOException ioe){
            ioe.printStackTrace();
            return null;
        }
        
    }
    
}
