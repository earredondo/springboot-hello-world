/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.config;

/**
 *
 * @author edgar
 */
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.mvc.SimpleControllerHandlerAdapter;

/**
 *
 * @author T42719
 */
@Configuration
@EnableWebMvc
@ComponentScan(basePackages = { "mx.org.banxico.dgcar.ancti.controlador",
                                "mx.org.banxico.dgcar.ancti.presentacion",
                                "mx.org.banxico.dgcar.ancti.config"})
public class WebConfig extends WebMvcConfigurerAdapter {
    
    /**
     *
     * @return
     */
    @Bean
    public MessageSource messageSource() {
       ResourceBundleMessageSource source = new ResourceBundleMessageSource();
       source.setBasename("messages");
       return source;
    }
    
    /**
     *
     * @return
     */
    @Bean
    public SimpleControllerHandlerAdapter simpleControllerHandlerAdapter() {
        return new SimpleControllerHandlerAdapter();
    }

}