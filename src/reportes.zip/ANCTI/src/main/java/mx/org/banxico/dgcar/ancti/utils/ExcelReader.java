/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.utils;

import java.io.InputStream;
import java.util.List;
import mx.org.banxico.dgcar.ancti.pojos.TipoPlantilla;

/**
 *
 * @author T42719
 * @param <T>
 */
public interface ExcelReader<T> {

    /**
     *
     * @param filePath
     * @param jasper
     * @return
     */
    public List<T> readObjects(String filePath, TipoPlantilla jasper);

    /**
     *
     * @param fileName
     * @param stream
     * @param jasper
     * @return
     */
    public List<T> readObjects(String fileName, InputStream stream, TipoPlantilla jasper);

    /**
     *
     * @param excel
     * @param jasper
     * @return
     */
    public InputStream agregarMetadatos(TipoPlantilla excel, TipoPlantilla jasper);
}
