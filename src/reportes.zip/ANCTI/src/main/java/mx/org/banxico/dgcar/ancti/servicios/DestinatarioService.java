/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.servicios;

import mx.org.banxico.dgcar.ancti.pojos.Destinatario;

/**
 *
 * @author edgar
 */
public interface DestinatarioService extends GenericService<Destinatario, String>{
    
}
