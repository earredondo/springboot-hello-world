/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.presentacion;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.el.ELContext;
import javax.el.ExpressionFactory;
import javax.el.ValueExpression;
import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.component.html.HtmlPanelGroup;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.mail.internet.AddressException;
import javax.validation.ConstraintViolationException;
import mx.org.banxico.dgcar.ancti.pojos.Destinatario;
import mx.org.banxico.dgcar.ancti.pojos.Estado;
import mx.org.banxico.dgcar.ancti.pojos.Metadato;
import mx.org.banxico.dgcar.ancti.pojos.Notificacion;
import mx.org.banxico.dgcar.ancti.pojos.Plantilla;
import mx.org.banxico.dgcar.ancti.pojos.TipoMetadato;
import mx.org.banxico.dgcar.ancti.pojos.TipoPlantilla;
import mx.org.banxico.dgcar.ancti.servicios.EstadoService;
import mx.org.banxico.dgcar.ancti.servicios.NotificacionService;
import mx.org.banxico.dgcar.ancti.servicios.TipoPlantillaService;
import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.primefaces.component.outputlabel.OutputLabel;
import org.primefaces.component.inputtextarea.InputTextarea;
import org.primefaces.context.RequestContext;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.ToggleSelectEvent;
import org.primefaces.event.UnselectEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.UploadedFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.mail.MailException;
import org.springframework.stereotype.Component;

/**
 *
 * @author T42719
 */
@Scope(value = "session")
@Component(value = "notificacionBean")
@ELBeanName(value = "notificacionBean")
@Join(path = "/", to = "/Notificaciones.jsf")
public class ControladorNotificaciones implements Serializable{
    
    @Autowired(required = true)
    private NotificacionService notificacionService;
    
    @Autowired(required = true)
    private TipoPlantillaService plantillaService;
    
    @Autowired(required = true)
    private EstadoService estadoService;
    
    private List<Notificacion> notificaciones;
    private List<Notificacion> notificacionesSeleccionadas;
    private Notificacion notificacion;
    private TipoPlantilla tipoPlantilla;
    private TipoPlantilla tipoPlantillaExcel;
    private Plantilla plantillaNotificacion;
    private StreamedContent plantilla;
    private List<Destinatario> destinatarios;
    private List<Destinatario> conCopias;
    private String metadato;
    private String vistaPrevia;
    private String accionFlujoTrabajo;
    private List<String> accionesFlujoTrabajo;
    private List<Metadato> metadatos;
    private List<TipoMetadato> tipoMetadatos;
    private boolean vistaPreviaDisabled;
    private boolean cancelarDisabled;
    private boolean eliminarDisabled;
    private boolean enviarDisabled;
    private boolean isUpdating;
    private boolean flujoDisabled;
    private Iterator iteraMetadatos;
    
    private HtmlPanelGroup panel;

    /**
     *
     */
    @PostConstruct
    public void init(){
        
        this.notificacion           = new Notificacion();
        this.plantillaNotificacion  = new Plantilla();
        this.metadatos              = new ArrayList();
        this.destinatarios          = new ArrayList();
        this.conCopias              = new ArrayList();
        this.setAccionesFlujoTrabajo((List<String>) new ArrayList());
        this.tipoPlantilla          = null;
        this.metadato               = null;
        this.isUpdating             = false;
        this.iteraMetadatos         = this.metadatos.iterator();
        
        this.actualizarMetadatos(null);
        
        Estado borrador = this.estadoService.findByName("Borrador");
        if(borrador == null){
            borrador = new Estado();
            borrador.setNombre("Borrador");
            this.estadoService.create(borrador);
        }
        
        this.notificacion.setEstado(borrador);
    }
    
    /**
     *
     */
    public ControladorNotificaciones(){
        this.vistaPreviaDisabled    = true;
        this.enviarDisabled         = true;
        this.cancelarDisabled       = true;
        this.eliminarDisabled       = true;
        this.flujoDisabled       = true;
    }
    
    /**
     *
     */
    public void crearNotificacion(){
        
        Iterator metadatosIterator = this.metadatos.iterator();
        Iterator tipoMetadatosIterator = this.tipoMetadatos.iterator();
        
        while(metadatosIterator.hasNext() && tipoMetadatosIterator.hasNext()){
            Metadato temp = (Metadato)metadatosIterator.next();
            temp.setTipoMetadato((TipoMetadato)tipoMetadatosIterator.next());
        }
        
        
        this.plantillaNotificacion.setNotificacion(this.notificacion);
        this.plantillaNotificacion.getMetadatos().addAll(this.metadatos);
        this.plantillaNotificacion.setTipoPlantilla(this.tipoPlantilla);
        
        this.notificacion.getPlantillas().add(this.plantillaNotificacion);
        
        this.notificacion.setDestinatarioNotificacions(new HashSet());
        try{
            for(Destinatario destinatario : this.destinatarios){
                this.notificacion.addDestinatario(destinatario, "destinatario");
            }
            if(this.conCopias != null){
                for(Destinatario cc : this.conCopias){
                    this.notificacion.addDestinatario(cc, "con copia");
                }
            }
            
            this.notificacionService.saveOrUpdate(this.notificacion);
            if(!this.isUpdating){ this.notificaciones.add(this.notificacion); }
            
            RequestContext.getCurrentInstance().execute("PF('modalRegistrarNotificacion').hide()");
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro exitoso", "Se registró la notificación correctamente."));
            this.init();
        }catch(Exception e){
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", " Ocurrió un error durante la transacción."));
            e.printStackTrace();
        }
        
    }
    
    /**
     *
     */
    public void eliminarNotificaciones(){
        for(Notificacion notificacion : this.notificacionesSeleccionadas){
            notificacionService.remove(notificacion);
            notificaciones.remove(notificacion);
        }
        this.init();
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Eliminación exitosa", "La notificación fue eliminada"));
    }
    
    /**
     *
     */
    public void enviarCorreo(){
        try {
            this.notificacionService.sendEmail(this.notificacionesSeleccionadas.get(0), this.vistaPrevia);
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Envío", "Se envío el correo electrónico.");
            FacesContext.getCurrentInstance().addMessage(null, message);
        } catch (MailException | AddressException ex) {
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Falló el envío del correo electrónico. Verifique la dirección e intentelo de nuevo.");
            FacesContext.getCurrentInstance().addMessage(null, message);
        }
    }
    
    /**
     *
     * @param event
     */
    public void importarExcel(FileUploadEvent event){
        UploadedFile file = event.getFile();
        try{
            List<Notificacion> notificaciones = this.notificacionService.importarNotificacionesExcel(file, this.tipoPlantillaExcel);
            for(Notificacion notificacion : notificaciones){
                this.notificacionService.saveOrUpdate(notificacion);
                this.notificaciones.add(notificacion);
            }
            FacesMessage message = new FacesMessage("Notificaciones importadas", file.getFileName());
            FacesContext.getCurrentInstance().addMessage(null, message);
        }catch(ConstraintViolationException cve){
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "El formato del correo electrónico es incorrecto");
            FacesContext.getCurrentInstance().addMessage(null, message);
        }
    }
    
    /**
     *
     * @param notificacion
     */
    public void verReporte(Notificacion notificacion){
        this.vistaPrevia = notificacionService.vistaPrevia(notificacion);
        RequestContext.getCurrentInstance().execute("PF('dialogVistaPrevia').show()");
    }
    
    /**
     *
     * @param event
     */
    public void actualizarMetadatos(final AjaxBehaviorEvent event){
        FacesContext context = FacesContext.getCurrentInstance();

        /* Quitar todos los hijos del panel */
        if(this.panel == null){ this.panel = new HtmlPanelGroup(); }
        this.panel.getChildren().clear();        
        if(this.tipoPlantilla == null){ return; }
        
        this.panel.setId("metadatosForm");
        
        this.tipoMetadatos = new ArrayList();
        this.tipoMetadatos.addAll(this.tipoPlantilla.getTipoMetadatos());
        this.tipoMetadatos.sort((left, right) -> (int) (left.getIdTipoMetadato() - right.getIdTipoMetadato()));
        
        this.metadatos = new ArrayList();
        
        for(TipoMetadato metadato : this.tipoMetadatos){
            Metadato tmp = new Metadato();
            tmp.setTipoMetadato(metadato);
            this.metadatos.add(tmp);
            
            OutputLabel label = (OutputLabel)context.getApplication().createComponent(OutputLabel.COMPONENT_TYPE);
            label.setFor("id_" + metadato.getNombre());
            label.setValue(metadato.getNombre() + ":");

            InputTextarea inputText = (InputTextarea)context.getApplication().createComponent(InputTextarea.COMPONENT_TYPE);
            inputText.setId("id_" + metadato.getNombre());
            inputText.setValueExpression("value", this.getValueExpression("#{notificacionBean.metadato}"));
            inputText.setValueExpression("required", this.getValueExpression("#{true}"));
            inputText.setValueExpression("maxlength", this.getValueExpression("#{(2047).intValue()}"));
            inputText.setValueExpression("autoResize", this.getValueExpression("#{false}"));
            
            this.panel.getChildren().add(label);
            this.panel.getChildren().add(inputText);
        }
    }
    
    /**Method to resolve a String to ValueExpression
     * @param data
     * @return
     */
    public ValueExpression getValueExpression(String data) {
        FacesContext fc = FacesContext.getCurrentInstance();
        Application app = fc.getApplication();
        ExpressionFactory elFactory = app.getExpressionFactory();
        ELContext elContext = fc.getELContext();
        ValueExpression valueExp = elFactory.createValueExpression(elContext, data, Object.class);
        return valueExp;
    }

    /**
     *
     * @throws Exception
     */
    public void verVistaPrevia() throws Exception{
        this.vistaPrevia = notificacionService.vistaPrevia(this.notificacionesSeleccionadas);
        if(this.vistaPrevia.startsWith("<DIFF_ERROR>")){
            this.vistaPrevia = "<html>\n" +
                                "<head>\n" +
                                "  <title></title>" +
                                "  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"/>" +
                                "</head>\n" +
                                "<body><p> ERROR AL GENERAR LA VISTA PREVIA</p></body></html>";
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Vista previa", "Las notificaciones deben usar la misma plantilla.");
            FacesContext.getCurrentInstance().addMessage(null, message);
        }else if(this.vistaPrevia.startsWith("<JASPER_ERROR>")){
            this.vistaPrevia = "<html><head></head><body><p>" + this .vistaPrevia + "</p></body></html>";
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Plantilla", "Se generó un error al compilar la plantilla.");
            FacesContext.getCurrentInstance().addMessage(null, message);
        }
    }
    
    /**
     *
     * @param event
     */
    public void onRowChange(SelectEvent event) {
        this.verificarCondiciones();
    }
    
    /**
     *
     * @param event
     */
    public void onRowChange(UnselectEvent event) {
        this.verificarCondiciones();
    }
    
    /**
     *
     * @param event
     */
    public void onRowChange(ToggleSelectEvent event) {
        this.verificarCondiciones();
    }
    
    private void verificarCondiciones(){
        this.vistaPreviaDisabled    = this.notificacionesSeleccionadas.isEmpty();
        this.flujoDisabled          = this.notificacionesSeleccionadas.size() != 1;
        this.enviarDisabled         = this.buscarEstado("Por enviar");
        this.cancelarDisabled       = this.buscarEstado("Enviada");
        this.eliminarDisabled       = this.buscarEstado("Borrador");
        
    }
    
    private boolean buscarEstado(String estado){
        boolean isDisabled = this.notificacionesSeleccionadas.isEmpty();
        for(Notificacion notificacion : this.notificacionesSeleccionadas){
            if( !estado.equalsIgnoreCase( notificacion.getEstado().getNombre() ) ){
                isDisabled = true;
                break;
            }
        }
        return isDisabled;
    }
    
    /**
     *
     * @param notificacion
     */
    public void editarNotificacion(Notificacion notificacion){
        this.notificacion           = notificacion;
        this.destinatarios          = notificacion.getDestinatarios();
        this.conCopias              = notificacion.getConCopias();
        this.tipoPlantilla          = notificacion.getPlantillas().iterator().next().getTipoPlantilla();
        this.plantillaNotificacion  = notificacion.getPlantillas().iterator().next();
        this.isUpdating = true;
        this.actualizarMetadatos(null);
        this.metadatos              = new ArrayList();
        this.metadatos.addAll(notificacion.getPlantillas().iterator().next().getMetadatos());
        this.metadatos.sort((left, right) -> (int) (left.getTipoMetadato().getIdTipoMetadato() - right.getTipoMetadato().getIdTipoMetadato()));
        this.iteraMetadatos = this.metadatos.iterator();
    }

    /**
     *
     */
    public void foo(){
        System.out.println("foo");
    }
    
    /**
     *
     */
    public void seguirFlujoDeTrabajo(){
        if( "Enviar".equalsIgnoreCase(this.accionFlujoTrabajo) ){
            this.vistaPrevia = notificacionService.vistaPrevia(this.notificacionesSeleccionadas);
            RequestContext.getCurrentInstance().execute("PF('dialogVistaPreviaEnviar').show()");
        }else{
            this.notificacionService.cambiarEstado(this.notificacionesSeleccionadas, this.accionFlujoTrabajo);
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, this.accionFlujoTrabajo, "Operación correcta.");
            FacesContext.getCurrentInstance().addMessage(null, message);
        }
    }
    
    /**
     *
     */
    public void cerrarSesion(){
        this.notificacionService.cerrarSesion();
        ExternalContext context = FacesContext.getCurrentInstance().getExternalContext();
        try{
            context.redirect("http://www.banxico.org.mx/");
        }catch(IOException ioe){
            ioe.printStackTrace();
        }
    }
    
    /* +++++++++++++++++++++++++++++ Getters y setters ++++++++++++++++++++++++++++++++++++ */
    
    /**
     *
     * @return
     */
    public List<Notificacion> getNotificaciones() {return this.notificaciones == null ? this.notificaciones = notificacionService.getAll() : this.notificaciones;}

    /**
     *
     * @param notificaciones
     */
    public void setNotificaciones(List<Notificacion> notificaciones) {this.notificaciones = notificaciones;}

    /**
     * @return the notificacion
     */
    public Notificacion getNotificacion() {
        return notificacion;
    }

    /**
     * @param notificacion the notificacion to set
     */
    public void setNotificacion(Notificacion notificacion) {
        this.notificacion = notificacion;
    }
    
    /**
     * @return the plantilla
     */
    public StreamedContent getPlantilla() {
        TipoPlantilla plantillaDescarga = this.plantillaService.findByName("plantillaNotificaciones.xlsx");
        InputStream stream = this.plantillaService.agregarMetadatos(plantillaDescarga, this.tipoPlantillaExcel);
        this.plantilla = new DefaultStreamedContent(stream, "application/vnd.ms-excel", plantillaDescarga.getNombre());
        
        return this.plantilla;
    }

    /**
     * @param plantilla the plantilla to set
     */
    public void setPlantilla(StreamedContent plantilla) {
        this.plantilla = plantilla;
    }

    /**
     * @return the destinatarios
     */
    public List<Destinatario> getDestinatarios() {
        return destinatarios;
    }

    /**
     * @param destinatarios the destinatarios to set
     */
    public void setDestinatarios(List<Destinatario> destinatarios) {
        this.destinatarios = destinatarios;
    }

    /**
     * @return the conCopias
     */
    public List<Destinatario> getConCopias() {
        return conCopias;
    }

    /**
     * @param conCopias the conCopias to set
     */
    public void setConCopias(List<Destinatario> conCopias) {
        this.conCopias = conCopias;
    }
    
    /**
     * @return the tipoPlantilla
     */
    public TipoPlantilla getTipoPlantilla() {
        return tipoPlantilla;
    }

    /**
     * @param tipoPlantilla the tipoPlantilla to set
     */
    public void setTipoPlantilla(TipoPlantilla tipoPlantilla) {
        this.tipoPlantilla = tipoPlantilla;
    }

    /**
     * @return the form
     */
    public HtmlPanelGroup getPanel() {
        return this.panel;
    }

    /**
     * @param panel the panel to set
     */
    public void setPanel(HtmlPanelGroup panel) {
        this.panel = panel;
    }
    
    /**
     * @return the metadato
     */
    public String getMetadato() {
        if(this.metadatos.isEmpty()){ return metadato; }
        if(this.iteraMetadatos == null){
            this.metadatos.sort((left, right) -> (int) (left.getTipoMetadato().getIdTipoMetadato() - right.getTipoMetadato().getIdTipoMetadato()));
            this.iteraMetadatos = this.metadatos.iterator(); 
        }
        else if( !this.iteraMetadatos.hasNext() ){ 
            this.metadatos.sort((left, right) -> (int) (left.getTipoMetadato().getIdTipoMetadato() - right.getTipoMetadato().getIdTipoMetadato()));
            this.iteraMetadatos = this.metadatos.iterator(); 
        }
        
        this.metadato = ((Metadato)this.iteraMetadatos.next()).getValor();
        return metadato;
    }

    /**
     * @param metadato the metadato to set
     */
    public void setMetadato(String metadato) {
        this.metadato = metadato;
        Metadato mtd;
        
        if(this.iteraMetadatos == null || !this.iteraMetadatos.hasNext()){
            this.iteraMetadatos = this.metadatos.iterator();
        }
        mtd = (Metadato)this.iteraMetadatos.next();
        mtd.setValor(metadato);
        mtd.setPlantilla(this.plantillaNotificacion);
    }

    /**
     * @return the vistaPrevia
     */
    public String getVistaPrevia() {
        return vistaPrevia;
    }

    /**
     * @param vistaPrevia the vistaPrevia to set
     */
    public void setVistaPrevia(String vistaPrevia) {
        this.vistaPrevia = vistaPrevia;
    }

    /**
     * @return the notificacionesSeleccionadas
     */
    public List<Notificacion> getNotificacionesSeleccionadas() {
        return notificacionesSeleccionadas;
    }

    /**
     * @param notificacionesSeleccionadas the notificacionesSeleccionadas to set
     */
    public void setNotificacionesSeleccionadas(List<Notificacion> notificacionesSeleccionadas) {
        this.notificacionesSeleccionadas = notificacionesSeleccionadas;
    }
    
    /**
     * @return the vistaPreviaEnabled
     */
    public boolean isVistaPreviaDisabled() {
        return vistaPreviaDisabled;
    }

    /**
     * @param vistaPreviaEnabled the vistaPreviaEnabled to set
     */
    public void setVistaPreviaDisabled(boolean vistaPreviaEnabled) {
        this.vistaPreviaDisabled = vistaPreviaEnabled;
    }

    /**
     * @return the tipoPlantillaExcel
     */
    public TipoPlantilla getTipoPlantillaExcel() {
        return tipoPlantillaExcel;
    }

    /**
     * @param tipoPlantillaExcel the tipoPlantillaExcel to set
     */
    public void setTipoPlantillaExcel(TipoPlantilla tipoPlantillaExcel) {
        this.tipoPlantillaExcel = tipoPlantillaExcel;
    }
    
    /**
     * @return the cancelarDisabled
     */
    public boolean isCancelarDisabled() {
        return cancelarDisabled;
    }

    /**
     * @param cancelarDisabled the cancelarDisabled to set
     */
    public void setCancelarDisabled(boolean cancelarDisabled) {
        this.cancelarDisabled = cancelarDisabled;
    }

    /**
     * @return the eliminarDisabled
     */
    public boolean isEliminarDisabled() {
        return eliminarDisabled;
    }

    /**
     * @param eliminarDisabled the eliminarDisabled to set
     */
    public void setEliminarDisabled(boolean eliminarDisabled) {
        this.eliminarDisabled = eliminarDisabled;
    }
    
    /**
     * @return the enviarDisabled
     */
    public boolean isEnviarDisabled() {
        return enviarDisabled;
    }

    /**
     * @param enviarDisabled the enviarDisabled to set
     */
    public void setEnviarDisabled(boolean enviarDisabled) {
        this.enviarDisabled = enviarDisabled;
    }
    
    /**
     * @return the flujoDisabled
     */
    public boolean isFlujoDisabled() {
        return flujoDisabled;
    }

    /**
     * @param flujoDisabled the flujoDisabled to set
     */
    public void setFlujoDisabled(boolean flujoDisabled) {
        this.flujoDisabled = flujoDisabled;
    }

    /**
     * @return the accionFlujoTrabajo
     */
    public String getAccionFlujoTrabajo() {
        return accionFlujoTrabajo;
    }

    /**
     * @param accionFlujoTrabajo the accionFlujoTrabajo to set
     */
    public void setAccionFlujoTrabajo(String accionFlujoTrabajo) {
        this.accionFlujoTrabajo = accionFlujoTrabajo;
    }

    /**
     * @return the accionesFlujoTrabajo
     */
    public List<String> getAccionesFlujoTrabajo() {
        if(this.notificacionesSeleccionadas != null && !this.notificacionesSeleccionadas.isEmpty()){
            this.accionesFlujoTrabajo = this.notificacionService.getTransicionesDisponibles(this.notificacionesSeleccionadas.get(0));
        }
        return accionesFlujoTrabajo;
    }

    /**
     * @param accionesFlujoTrabajo the accionesFlujoTrabajo to set
     */
    public void setAccionesFlujoTrabajo(List<String> accionesFlujoTrabajo) {
        this.accionesFlujoTrabajo = accionesFlujoTrabajo;
    }
    
}
