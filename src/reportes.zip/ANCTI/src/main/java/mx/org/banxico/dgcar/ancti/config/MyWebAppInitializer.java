/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.config;

/**
 *
 * @author edgar
 */
import com.sun.faces.config.ConfigureListener;
import javax.faces.webapp.FacesServlet;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;
import org.springframework.ws.transport.http.MessageDispatcherServlet;

/**
 *
 * @author T42719
 */
public class MyWebAppInitializer
      extends AbstractAnnotationConfigDispatcherServletInitializer {

    /**
     *
     * @return
     */
    @Override
    protected Class<?>[] getRootConfigClasses() {
       return new Class[] { AppConfig.class, CustomWebSecurityConfiguration.class };
    }

    /**
     *
     * @return
     */
    @Override
    protected Class<?>[] getServletConfigClasses() {
       return new Class[] { WebConfig.class, WebServiceConfig.class };
    }

    /**
     *
     * @return
     */
    @Override
    protected String[] getServletMappings() {
       return new String[] { "/" };
    }

    /* JSF */

    /**
     *
     * @param servletContext
     * @throws ServletException
     */
    
    
    @Override
    public void onStartup(ServletContext servletContext)
            throws ServletException {

        ServletRegistration.Dynamic facesServlet = servletContext.addServlet("Faces Servlet", FacesServlet.class);
        facesServlet.setLoadOnStartup(1);
        facesServlet.addMapping("/");
        facesServlet.addMapping("/javax.faces.resources/*");
        servletContext.setInitParameter("javax.faces.PROJECT_STAGE", "Development");
        servletContext.setInitParameter("javax.faces.FACELETS_REFRESH_PERIOD", "1");
        servletContext.setInitParameter("javax.faces.FACELETS_LIBRARIES", "/WEB-INF/springsecurity.taglib.xml");
        servletContext.setInitParameter("primefaces.FONT_AWESOME", "true");
        servletContext.addListener(ConfigureListener.class);

        AnnotationConfigWebApplicationContext context = new AnnotationConfigWebApplicationContext();
        context.setConfigLocation(WebServiceConfig.class.getName());

        MessageDispatcherServlet servlet = new MessageDispatcherServlet();
        servlet.setContextClass(AnnotationConfigWebApplicationContext.class);
        servlet.setApplicationContext(context);
        servlet.setTransformWsdlLocations(true);
        ServletRegistration.Dynamic wsServlet = servletContext.addServlet("MessageDispatcherServlet", servlet);
        wsServlet.setLoadOnStartup(1);
        wsServlet.addMapping("/ws/*");
        
        super.onStartup(servletContext);
    }

}