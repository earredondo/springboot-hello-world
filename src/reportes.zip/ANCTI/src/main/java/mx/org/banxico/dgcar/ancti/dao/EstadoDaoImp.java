/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.dao;

import mx.org.banxico.dgcar.ancti.pojos.Estado;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

/**
 *
 * @author T42719
 */
@Repository
public class EstadoDaoImp extends GenericDaoImp<Estado, Long> implements EstadoDao{
    
    /**
     *
     * @return
     */
    public Session openSession(){
        return super.sessionFactory().openSession();
    }

    /**
     *
     * @param nombre
     * @return
     */
    @Override
    public Estado findByNaturalId(String nombre) {
        try (Session sesion = openSession()) {
            return sesion.byNaturalId(Estado.class).using("nombre", nombre).load();
        }
    }
    
}
