/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.presentacion;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import mx.org.banxico.dgcar.ancti.pojos.TipoPlantilla;
import mx.org.banxico.dgcar.ancti.servicios.TipoPlantillaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 *
 * @author T42719
 */
@Component(value = "tipoPlantillaConverter")
public class TipoPlantillaConverter implements Converter{
 
    @Autowired(required = true)
    private TipoPlantillaService service;
    
    /**
     *
     * @param fc
     * @param uic
     * @param value
     * @return
     */
    @Override
    public Object getAsObject(FacesContext fc, UIComponent uic, String value) {
        if(value != null && value.trim().length() > 0) {
            try {
                for(TipoPlantilla plantilla : service.getAll()){
                    if (value.equals(plantilla.getNombre())) {
                        return plantilla;
                    }
                }
                return null;
            } catch(NumberFormatException e) {
                e.printStackTrace();
                throw new ConverterException(new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error de conversión", "No es una plantilla válida."));
            }
        }
        else {
            return null;
        }
    }
 
    /**
     *
     * @param fc
     * @param uic
     * @param object
     * @return
     */
    @Override
    public String getAsString(FacesContext fc, UIComponent uic, Object object) {
        if(object != null) {
            return ((TipoPlantilla) object).getNombre();
        }
        else {
            return null;
        }
    }

}
