/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.ws;

import mx.org.banxico.dgcar.ancti.pojos.Estado;
import mx.org.banxico.dgcar.ancti.pojos.Metadato;
import mx.org.banxico.dgcar.ancti.pojos.Notificacion;
import mx.org.banxico.dgcar.ancti.pojos.Plantilla;
import mx.org.banxico.dgcar.ancti.servicios.EstadoService;
import mx.org.banxico.dgcar.ancti.servicios.NotificacionService;
import mx.org.banxico.dgcar.ancti.servicios.TipoPlantillaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

/**
 *
 * @author T42719
 */
@Endpoint
public class WSEndpointImpl implements WSEndpoint{

    private static final String NAMESPACE_URI = "http://spring.io/guides/gs-producing-web-service";
    
    @Autowired
    private NotificacionService notificacionService;
    
    @Autowired
    private TipoPlantillaService tipoPlantillaService;
    
    @Autowired
    private EstadoService estadoService;
    
    /**
     *
     * @param request
     * @return
     */
    @Override
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getNotificacionRequest")
    @ResponsePayload
    public GetNotificacionResponse getNotificacion( @RequestPayload GetNotificacionRequest request) {
        
        GetNotificacionResponse response = new GetNotificacionResponse();
        response.setNotificacion(this.notificacionService.find(request.getId()));
        
        if(response.getNotificacion() == null){ return response; }
        
        response.getNotificacion().getDestinatarios();
        response.getNotificacion().getConCopias();
        
        return response;
    }
    
    /**
     *
     * @param request
     * @return
     */
    @Override
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "setNotificacionRequest")
    @ResponsePayload
    public SetNotificacionResponse crearNotificacion( @RequestPayload SetNotificacionRequest request) {
        
        SetNotificacionResponse response = new SetNotificacionResponse();
        Notificacion notificacion = request.getNotificacion();
        
        notificacion.addAllDestinatarios(notificacion.getDestinatarios(), "destinatario");
        notificacion.addAllDestinatarios(notificacion.getConCopias(), "con copia");
        
        Estado borrador = this.estadoService.findByName("Borrador");
        if(borrador == null){
            borrador = new Estado();
            borrador.setNombre("Borrador");
            this.estadoService.create(borrador);
        }
        notificacion.setEstado(borrador);
        
        Plantilla plantilla = notificacion.getPlantillas().iterator().next();
        plantilla.setNotificacion(notificacion);
        
        for(Metadato metadato : notificacion.getPlantillas().iterator().next().getMetadatos()){
            metadato.setPlantilla(plantilla);
        }
        
        this.notificacionService.saveOrUpdate(notificacion);
        response.setNotificacion(notificacion);
        
        return response;
    }
    
    /**
     *
     * @param request
     * @return
     */
    @Override
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getTipoPlantillaRequest")
    @ResponsePayload
    public GetTipoPlantillaResponse getTipoPlantillas( @RequestPayload GetTipoPlantillaRequest request){
        
        GetTipoPlantillaResponse response = new GetTipoPlantillaResponse();
        
        response.setTipoPlantilla(this.tipoPlantillaService.getAll());
        
        return response;
    }
    
}
