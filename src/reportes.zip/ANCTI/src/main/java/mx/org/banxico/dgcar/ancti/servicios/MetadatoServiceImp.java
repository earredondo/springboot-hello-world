/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.servicios;

import mx.org.banxico.dgcar.ancti.dao.MetadatoDao;
import mx.org.banxico.dgcar.ancti.dao.GenericDao;
import mx.org.banxico.dgcar.ancti.pojos.Metadato;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 *
 * @author edgar
 */
@Service
public class MetadatoServiceImp extends GenericServiceImp<Metadato, Long>
        implements MetadatoService {
   
    private MetadatoDao metadatoDao;

    /**
     *
     */
    public MetadatoServiceImp(){
 
    }

    /**
     *
     * @param genericDao
     */
    @Autowired
    public MetadatoServiceImp(
            @Qualifier("metadatoDaoImp") GenericDao<Metadato, Long> genericDao) {
        super(genericDao);
        this.metadatoDao = (MetadatoDao) genericDao;
    }

}