/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.dao;

import java.util.List;
import org.hibernate.Session;

/**
 *
 * @author T42719
 * @param <E>
 * @param <K>
 */
public interface GenericDao<E,K> {

    /**
     *
     * @param entity
     */
    public void create(E entity);

    /**
     *
     * @param entity
     */
    public void saveOrUpdate(E entity);

    /**
     *
     * @param entity
     */
    public void update(E entity);

    /**
     *
     * @param entity
     */
    public void remove(E entity);

    /**
     *
     * @param key
     * @return
     */
    public E find(K key);

    /**
     *
     * @return
     */
    public List<E> getAll();

    /**
     *
     * @return
     */
    public Session currentSession();
}