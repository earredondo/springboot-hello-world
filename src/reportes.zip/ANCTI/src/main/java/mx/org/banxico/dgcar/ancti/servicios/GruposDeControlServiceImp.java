/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.servicios;

import mx.org.banxico.dgcar.ancti.aspectos.Loggable;
import mx.org.banxico.dgcar.ancti.dao.GruposDeControlDao;
import mx.org.banxico.dgcar.ancti.dao.GenericDao;
import mx.org.banxico.dgcar.ancti.pojos.GruposDeControl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author edgar
 */
@Service
public class GruposDeControlServiceImp extends GenericServiceImp<GruposDeControl, Long>
        implements GruposDeControlService {
   
    private GruposDeControlDao administradorDao;

    /**
     *
     */
    public GruposDeControlServiceImp(){
 
    }

    /**
     *
     * @param genericDao
     */
    @Autowired
    public GruposDeControlServiceImp(
             /*@Qualifier("admininstradorSistemaDaoImp") */GenericDao<GruposDeControl, Long> genericDao) {
        super(genericDao);
        this.administradorDao = (GruposDeControlDao) genericDao;
    }
    
    /**
     *
     * @param nombre
     * @return
     */
    @Override
    @Loggable
    @Transactional(propagation = Propagation.REQUIRED)
    public GruposDeControl findByName(String nombre) {
        return this.administradorDao.findByNaturalId(nombre);
    }
    
}