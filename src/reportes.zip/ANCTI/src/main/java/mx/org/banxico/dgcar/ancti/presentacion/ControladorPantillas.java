/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.presentacion;

import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import mx.org.banxico.dgcar.ancti.pojos.TipoMetadato;
import mx.org.banxico.dgcar.ancti.pojos.TipoPlantilla;
import mx.org.banxico.dgcar.ancti.servicios.TipoPlantillaService;
import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 *
 * @author T42719
 */
@Scope(value = "session")
@Component(value = "plantillaBean")
@ELBeanName(value = "plantillaBean")
@Join(path = "/", to = "/Notificaciones.jsf")
public class ControladorPantillas implements Serializable{
    
    @Autowired(required = true)
    private TipoPlantillaService plantillaService;
    
    private TipoPlantilla plantilla;
    private List<TipoPlantilla> plantillas;

    /**
     * @return the plantilla
     */
    public TipoPlantilla getPlantilla() {
        return plantilla;
    }

    /**
     * @param plantilla the plantilla to set
     */
    public void setPlantilla(TipoPlantilla plantilla) {
        this.plantilla = plantilla;
    }

    /**
     * @return the plantillas
     */
    public List<TipoPlantilla> getPlantillas() {
        return this.plantillas == null ? this.plantillas = this.plantillaService.getAll() : this.plantillas;
    }

    /**
     * @param plantillas the plantillas to set
     */
    public void setPlantillas(List<TipoPlantilla> plantillas) {
        this.plantillas = plantillas;
    }
    
    /**
     *
     * @return
     */
    public List<TipoPlantilla> getPlantillasJasper(){
        List<TipoPlantilla> pj = new ArrayList();        
        for(TipoPlantilla plantilla : this.getPlantillas()){
            if(plantilla.getTipo().equalsIgnoreCase("Jasper")){ pj.add(plantilla); }
        }
        return pj;
    }
    
    /**
     *
     * @param event
     */
    public void subirPlantilla(FileUploadEvent event){
        UploadedFile file = event.getFile();
        
        TipoPlantilla nuevaPlantilla = new TipoPlantilla();
        nuevaPlantilla.setNombre(file.getFileName());
        
        try{
            InputStream is = file.getInputstream();
            byte[] contenido = new byte[is.available()];
            
            is.read(contenido);
            nuevaPlantilla.setContenido(contenido);
            
            if(file.getFileName().endsWith("xlsx") || file.getFileName().endsWith("xls")){
                
                nuevaPlantilla.setTipo("Excel");
                
            }else if(file.getFileName().endsWith("jrxml")){
                
                nuevaPlantilla.setTipo("Jasper");
                String textoPlantilla = new String(contenido, 0, contenido.length);
                
                Matcher m = Pattern.compile("\\$P\\{(.*?)\\}").matcher(textoPlantilla);
                while(m.find()) {
                    TipoMetadato metadato = new TipoMetadato();
                    metadato.setNombre(m.group(1));
                    metadato.setTipo("P");
                    metadato.setTipoPlantilla(nuevaPlantilla);
                    nuevaPlantilla.getTipoMetadatos().add(metadato);
                }
                
                m = Pattern.compile("\\$F\\{(.*?)\\}").matcher(textoPlantilla);
                while(m.find()) {
                    TipoMetadato metadato = new TipoMetadato();
                    metadato.setNombre(m.group(1));
                    metadato.setTipo("F");
                    metadato.setTipoPlantilla(nuevaPlantilla);
                    nuevaPlantilla.getTipoMetadatos().add(metadato);
                }
                
            }else{
                FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "No se admiten archivos con esa extensión.");
                FacesContext.getCurrentInstance().addMessage(null, message);
                return;
            }
            
            this.plantillaService.create(nuevaPlantilla);
            this.plantillas.add(nuevaPlantilla);
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Plantilla guardada", file.getFileName() + ".");
            FacesContext.getCurrentInstance().addMessage(null, message);
            
        }catch(Exception e){
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Plantilla " + file.getFileName() + " duplicada.");
            FacesContext.getCurrentInstance().addMessage(null, message);
        }
    }
    
    /**
     *
     * @param plantilla
     */
    public void eliminarPlantilla(TipoPlantilla plantilla){        
        try{
            plantillaService.remove(plantilla);
            plantillas.remove(plantilla);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Plantilla eliminada", plantilla.getNombre()));
        }catch(Exception e){
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "No puede eliminarse la plantilla mientras tenga notificaciones asociadas."));
        }
    }
    
}
