/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.utils;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author T42719
 */
public class FSM {
    //Etiquetas de estados y transiciones
    private String[]    etiquetasEstados;
    private String[]    etiquetasTransiciones;
    private String[][]  autorizaciones;
    
    //Tabla de transiciones
    private final int[][] transiciones;
    
    //Estado actual
    private int actual;
    
    /**
     *
     * @param transiciones
     * @param estadoInicial
     */
    public FSM(int[][] transiciones, int estadoInicial){
        this.transiciones = transiciones;
        this.actual = estadoInicial;
    }
    
    /**
     *
     * @param transiciones
     * @param estadoInicial
     * @param etiquetasEstados
     * @param etiquetasTransiciones
     */
    public FSM(int[][] transiciones, int estadoInicial, String[] etiquetasEstados, String[] etiquetasTransiciones){
        this(transiciones, estadoInicial);
        this.etiquetasEstados = etiquetasEstados;
        this.etiquetasTransiciones = etiquetasTransiciones;
    }
    
    /**
     *
     * @param transiciones
     * @param estadoInicial
     * @param etiquetasEstados
     * @param etiquetasTransiciones
     * @param autorizaciones
     */
    public FSM(int[][] transiciones, int estadoInicial, String[] etiquetasEstados, String[] etiquetasTransiciones, String[][] autorizaciones){
        this(transiciones, estadoInicial);
        this.etiquetasEstados = etiquetasEstados;
        this.etiquetasTransiciones = etiquetasTransiciones;
        this.autorizaciones = autorizaciones;
    }
    
    /**
     *
     * @param transicion
     * @return
     */
    public boolean next(int transicion){
        int siguiente = this.transiciones[actual][transicion];
        if(siguiente == -1){ return false; }
        actual = siguiente;
        return true;
    }
    
    /**
     *
     * @param transicion
     * @return
     */
    public boolean next(String transicion){
        for(int i = 0; i < this.getEtiquetasTransiciones().length; i++){
            if(transicion.equalsIgnoreCase(this.getEtiquetasTransiciones()[i])){
                return next(i);
            }
        }
        return false;
    }
    
    /**
     *
     * @param actual
     */
    public void setActual(int actual){
        this.actual = actual;
    }
    
    /**
     *
     * @return
     */
    public int getActual(){
        return this.actual;
    }
    
    /**
     *
     * @param actual
     */
    public void setActual(String actual){
        for(int i = 0; i < this.getEtiquetasEstados().length; i++){
            if(actual.equalsIgnoreCase(this.getEtiquetasEstados()[i])){
                setActual(i);
                break;
            }
        }
    }
    
    /**
     *
     * @param estado
     * @return
     */
    public List<Integer> transicionesDisponibles(int estado){
        List<Integer> transiciones = new ArrayList();
        for(int i = 0; i < this.transiciones[estado].length; i++){
            if(this.transiciones[estado][i] != -1){
                transiciones.add(i);
            }
        }
        return transiciones;
    }
    
    /**
     *
     * @param estado
     * @return
     */
    public List<Integer> transicionesDisponiblesInt(String estado){
        int estadoInt = -1;
        for(int i = 0; i < this.getEtiquetasEstados().length; i++){
            if(this.getEtiquetasEstados()[i].equalsIgnoreCase(estado)){
                estadoInt = i;
            }
        }
        
        return transicionesDisponibles(estadoInt);
    }
    
    /**
     *
     * @param estado
     * @return
     */
    public List<String> transicionesDisponibles(String estado){
        
        List<Integer> transicionesInt = this.transicionesDisponiblesInt(estado);
        List<String> transicionesString = new ArrayList();
        
        for(Integer transicion : transicionesInt){
            transicionesString.add(this.getEtiquetasTransiciones()[transicion]);
        }
        
        return transicionesString;
    }

    /**
     * @return the etiquetasEstados
     */
    public String[] getEtiquetasEstados() {
        return etiquetasEstados;
    }

    /**
     * @param etiquetasEstados the etiquetasEstados to set
     */
    public void setEtiquetasEstados(String[] etiquetasEstados) {
        this.etiquetasEstados = etiquetasEstados;
    }

    /**
     * @return the etiquetasTransiciones
     */
    public String[] getEtiquetasTransiciones() {
        return etiquetasTransiciones;
    }

    /**
     * @param etiquetasTransiciones the etiquetasTransiciones to set
     */
    public void setEtiquetasTransiciones(String[] etiquetasTransiciones) {
        this.etiquetasTransiciones = etiquetasTransiciones;
    }

    /**
     * @return the autorizaciones
     */
    public String[][] getAutorizaciones() {
        return autorizaciones;
    }

    /**
     * @param autorizaciones the autorizaciones to set
     */
    public void setAutorizaciones(String[][] autorizaciones) {
        this.autorizaciones = autorizaciones;
    }

}
