//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.2.7 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2018.02.12 a las 02:35:12 PM CST 
//


package mx.org.banxico.dgcar.ancti.ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import mx.org.banxico.dgcar.ancti.pojos.Notificacion;

/**
 *
 * @author T42719
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "notificacion"
})
@XmlRootElement(name = "setNotificacionResponse")
public class SetNotificacionResponse {

    @XmlElement(required = true)
    private Notificacion notificacion;

    /**
     * @return the notificacion
     */
    public Notificacion getNotificacion() {
        return notificacion;
    }

    /**
     * @param notificacion the notificacion to set
     */
    public void setNotificacion(Notificacion notificacion) {
        this.notificacion = notificacion;
    }

    
}
