/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.servicios;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.mail.Message;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import mx.org.banxico.dgcar.ancti.aspectos.Loggable;
import mx.org.banxico.dgcar.ancti.dao.GenericDao;
import mx.org.banxico.dgcar.ancti.dao.NotificacionDao;
import mx.org.banxico.dgcar.ancti.pojos.Destinatario;
import mx.org.banxico.dgcar.ancti.pojos.Estado;
import mx.org.banxico.dgcar.ancti.pojos.Metadato;
import mx.org.banxico.dgcar.ancti.pojos.Notificacion;
import mx.org.banxico.dgcar.ancti.pojos.Plantilla;
import mx.org.banxico.dgcar.ancti.pojos.TipoPlantilla;
import mx.org.banxico.dgcar.ancti.seguridad.AuthenticationFacade;
import mx.org.banxico.dgcar.ancti.seguridad.BanxicoAuthenticationToken;
import mx.org.banxico.dgcar.ancti.utils.ExcelReader;
import mx.org.banxico.dgcar.ancti.utils.FSM;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.HtmlExporter;
import net.sf.jasperreports.export.Exporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleHtmlExporterOutput;
import org.primefaces.model.UploadedFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author edgar
 */
@Service
public class NotificacionServiceImp extends GenericServiceImp<Notificacion, Long>
        implements NotificacionService {
   
    private NotificacionDao notificacionDao;
    
    @Autowired(required = true)
    private ExcelReader excelReader;
    
    @Autowired(required = true)
    private JavaMailSender emailSender;

    @Autowired(required = true)
    private EstadoService estadoService;
    
    @Autowired(required = true)
    private FSM maquinaDeEstados;
    
    @Autowired
    private AuthenticationFacade authenticationFacade;
    
    /**
     *
     */
    public NotificacionServiceImp(){
 
    }

    /**
     *
     * @param genericDao
     */
    @Autowired
    public NotificacionServiceImp(
            @Qualifier("notificacionDaoImp") GenericDao<Notificacion, Long> genericDao) {
        super(genericDao);
        this.notificacionDao = (NotificacionDao) genericDao;
    }
    
    /**
     *
     * @param file
     * @param jasper
     * @return
     */
    @Override
    @Loggable
    public List<Notificacion> importarNotificacionesExcel(UploadedFile file, TipoPlantilla jasper){
        try {
            InputStream is = file.getInputstream();
            return this.excelReader.readObjects(file.getFileName(), is, jasper);
        } catch (IOException ex) {
            return new ArrayList();
        }
    }
    
    /**
     *
     * @param notificacion
     * @return
     */
    @Override
    @Loggable
    public String vistaPrevia(Notificacion notificacion){
        if(notificacion.getPlantillas().isEmpty()) { return "No se tiene una plantilla asignada."; }
        if(notificacion.getPlantillas().size() > 1) { return "Se tiene más de una plantilla asociada."; }
        Plantilla plantilla = notificacion.getPlantillas().iterator().next();
        InputStream contenidoTipoPlantilla = new ByteArrayInputStream(plantilla.getTipoPlantilla().getContenido());
        try{
            
            JasperReport reporte = JasperCompileManager.compileReport(contenidoTipoPlantilla);
            Map parametros = new HashMap();
            Map bean = new HashMap();

            for(Metadato metadato : plantilla.getMetadatos()){
                
                if(metadato.getTipoMetadato().getTipo().equalsIgnoreCase("F")){
                    bean.put(metadato.getTipoMetadato().getNombre(), metadato.getValor());
                    continue;
                }
                
                parametros.put(metadato.getTipoMetadato().getNombre(), metadato.getValor());
            }
            
            List beanList = new ArrayList();
            beanList.add(bean);

            JRDataSource jrDataSource = new JRBeanCollectionDataSource(beanList);
            
            JasperPrint jasperPrint = JasperFillManager.fillReport(reporte, parametros, jrDataSource);
            
            final ByteArrayOutputStream out = new ByteArrayOutputStream();
            final Exporter exporter;
            exporter = new HtmlExporter();
            exporter.setExporterOutput(new SimpleHtmlExporterOutput(out));
            exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
            exporter.exportReport();
            
            try{
                return out.toString(StandardCharsets.UTF_8.name());
            }catch(UnsupportedEncodingException uee){
                return out.toString();
            }
            
        }catch(JRException jre){
            jre.printStackTrace();
            return "No se pudo obtener la vista previa.";
        }
    }
    
    /**
     *
     * @param notificaciones
     * @return
     */
    @Override
    @Loggable
    public String vistaPrevia(List<Notificacion> notificaciones){
        if(this.verificarMismoTipoPlantilla(notificaciones) == null){ return "<DIFF_ERROR>"; }
        Plantilla plantilla = notificaciones.get(0).getPlantillas().iterator().next();
        InputStream contenidoTipoPlantilla = new ByteArrayInputStream(plantilla.getTipoPlantilla().getContenido());
        try{
            
            JasperReport reporte = JasperCompileManager.compileReport(contenidoTipoPlantilla);
            Map parametros = new HashMap();
            List beanList = new ArrayList();            
            
            /* Los campos son distintos en cada notificaciones */
            for(Notificacion notificacion : notificaciones){
                
                plantilla = notificacion.getPlantillas().iterator().next();
                Map bean = new HashMap();

                for(Metadato metadato : plantilla.getMetadatos()){

                    if(metadato.getTipoMetadato().getTipo().equalsIgnoreCase("F")){
                        bean.put(metadato.getTipoMetadato().getNombre(), metadato.getValor());
                        continue;
                    }

                    parametros.put(metadato.getTipoMetadato().getNombre(), metadato.getValor());
                }

                beanList.add(bean);
            }

            JRDataSource jrDataSource = new JRBeanCollectionDataSource(beanList);
            
            JasperPrint jasperPrint = JasperFillManager.fillReport(reporte, parametros, jrDataSource);
            
            final ByteArrayOutputStream out = new ByteArrayOutputStream();
            final Exporter exporter;
            exporter = new HtmlExporter();
            exporter.setExporterOutput(new SimpleHtmlExporterOutput(out));
            exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
            exporter.exportReport();
            
            try{
                return out.toString(StandardCharsets.UTF_8.name());
            }catch(UnsupportedEncodingException uee){
                return out.toString();
            }
            
        }catch(JRException jre){
            jre.printStackTrace();
            return "<JASPER_ERROR>\n" + jre.getMessage();
        }
    }
    
    private String verificarMismoTipoPlantilla(List<Notificacion> notificaciones){
        Notificacion notificacion = notificaciones.get(0);
        if(notificacion.getPlantillas().isEmpty()) { return "No se tiene una plantilla asignada."; }
        if(notificacion.getPlantillas().size() > 1) { return "Se tiene más de una plantilla asociada."; }
        TipoPlantilla plantilla = notificacion.getPlantillas().iterator().next().getTipoPlantilla();
        for(Notificacion ntf : notificaciones){
            if( !plantilla.equals( ntf.getPlantillas().iterator().next().getTipoPlantilla() ) ){ return null; }
        }
        return "";
    }
    
    /**
     *
     * @param notificacion
     * @param contenido
     * @throws MailException
     * @throws AddressException
     */
    @Override
    @Loggable
    public void sendEmail(Notificacion notificacion, String contenido) throws MailException, AddressException{
        /* Validar si la transición de estado es válida */
        String estadoActual = notificacion.getEstado().getNombre();
        String transicion   = "Enviar";
        
        this.maquinaDeEstados.setActual(estadoActual);
        if(!this.maquinaDeEstados.next(transicion)){ return; }
        
        List<InternetAddress> to = new ArrayList();
        List<InternetAddress> cc = new ArrayList();
        
        try {
        
            for(Destinatario destinatario : notificacion.getDestinatarios()){
                to.add(new InternetAddress( destinatario.getCorreo() ));
            }

            for(Destinatario conCopia : notificacion.getConCopias()){
                cc.add(new InternetAddress( conCopia.getCorreo() ));
            }


            MimeMessagePreparator preparator = new MimeMessagePreparator() {

                @Override
                public void prepare(MimeMessage mimeMessage) throws Exception {

                    mimeMessage.setRecipients(Message.RecipientType.TO, (InternetAddress[])to.toArray());
                    mimeMessage.setRecipients(Message.RecipientType.CC, (InternetAddress[])cc.toArray());
                    mimeMessage.setSubject(notificacion.getAsunto());
                    mimeMessage.setContent(contenido, "text/html; charset=utf-8");
                }
            };
        
            this.emailSender.send(preparator);
        }
        catch (MailException | AddressException ex) {
            throw ex;
        }
        
    }
    
    /**
     *
     * @param notificacion
     */
    @Override
    @Transactional(propagation = Propagation.REQUIRED/*, readOnly = true*/)
    public void cancelarNotificacion(Notificacion notificacion){
        Estado cancelada = this.estadoService.findByName("Cancelada");
        if(cancelada == null){
            cancelada = new Estado();
            cancelada.setNombre("Cancelada");
            this.estadoService.create(cancelada);
        }
        
        notificacion.setEstado(cancelada);
        this.notificacionDao.saveOrUpdate(notificacion);
    }
    
    /**
     *
     * @param notificacion
     * @return
     */
    @Override
    public List<String> getTransicionesDisponibles(Notificacion notificacion){
        
        BanxicoAuthenticationToken authentication = (BanxicoAuthenticationToken)authenticationFacade.getAuthentication();
        Collection <GrantedAuthority> authorities = authentication.getAuthorities();

        List<Integer> transiciones = this.maquinaDeEstados.transicionesDisponiblesInt(notificacion.getEstado().getNombre());
        List<String> transicionesString = new ArrayList();
        String[][] autorizaciones = this.maquinaDeEstados.getAutorizaciones();
        
         /* Verificar si el usuario autenticado tiene autoridad para realizar la transicion de estado */
        for(Integer indice : transiciones){
            for(GrantedAuthority authority : authorities){
                if(Arrays.asList(autorizaciones[indice]).contains(authority.getAuthority())){
                    transicionesString.add(this.maquinaDeEstados.getEtiquetasTransiciones()[indice]);
                    break;
                }
            }
        }
        
        return transicionesString;
    }
    
    /**
     *
     * @param notificaciones
     * @param transicion
     */
    @Override
    @Transactional(propagation = Propagation.REQUIRED/*, readOnly = true*/)
    public void cambiarEstado(List<Notificacion> notificaciones, String transicion){
        List<Notificacion> notificacionesValidas = new ArrayList();
        String estadoActual;
        String estadoSiguiente;
        Estado siguiente;
        /* Validar si la transición de estado es válida */
        for(Notificacion notificacion : notificaciones){
            estadoActual = notificacion.getEstado().getNombre();
        
            this.maquinaDeEstados.setActual(estadoActual);
            if(!this.maquinaDeEstados.next(transicion)){ continue; }
            notificacionesValidas.add(notificacion);
        }
        
        /* Realizar transiciones */
        for(Notificacion notificacion : notificacionesValidas){
            estadoActual = notificacion.getEstado().getNombre();
        
            this.maquinaDeEstados.setActual(estadoActual);
            this.maquinaDeEstados.next(transicion);
            estadoSiguiente = this.maquinaDeEstados.getEtiquetasEstados()[this.maquinaDeEstados.getActual()];
            
            siguiente = this.estadoService.findByName(estadoSiguiente);
            if(siguiente == null){
                siguiente = new Estado();
                siguiente.setNombre(estadoSiguiente);
                this.estadoService.create(siguiente);
            }
            
            notificacion.setEstado(siguiente);
            this.notificacionDao.update(notificacion);
        }
           
    }
    
    /**
     *
     */
    @Override
    public void cerrarSesion(){
        this.authenticationFacade.setAuthentication(null);
    }
    
}