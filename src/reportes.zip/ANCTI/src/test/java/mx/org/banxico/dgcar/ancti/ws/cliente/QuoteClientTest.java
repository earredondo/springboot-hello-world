/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.ws.cliente;

import javax.xml.transform.Source;
import mx.org.banxico.dgcar.ancti.config.AppConfig;
import mx.org.banxico.dgcar.ancti.config.WebServiceConfig;
import org.junit.After;
import org.junit.Test;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.xml.transform.StringSource;
import org.springframework.ws.test.server.MockWebServiceClient;
import static org.springframework.ws.test.server.RequestCreators.withPayload;
import static org.springframework.ws.test.server.ResponseMatchers.noFault;
import static org.springframework.ws.test.server.ResponseMatchers.payload;

/**
 *
 * @author T42719
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {WebServiceConfig.class, AppConfig.class})
public class QuoteClientTest {
    
    @Autowired
    private ApplicationContext applicationContext;
    
    private MockWebServiceClient mockClient;
    
    /**
     *
     */
    public QuoteClientTest() {
    }
    
    /**
     *
     */
    @Before
    public void setUp() {
        
        mockClient = MockWebServiceClient.createClient(applicationContext);
        
    }
    
    /**
     *
     */
    @After
    public void tearDown() {
        
    }

    /**
     * Test of getQuote method, of class QuoteClient.
     */
    @Test
    public void testGetQuote() {
        Source requestPayload = new StringSource(
                "<ns2:getNotificacionRequest xmlns:ns2=\"http://spring.io/guides/gs-producing-web-service\">" +
                        "<ns2:id>0</ns2:id>" +
                "</ns2:getNotificacionRequest>");

        Source responsePayload = new StringSource(
                "<ns2:getNotificacionResponse xmlns:ns2=\"http://spring.io/guides/gs-producing-web-service\"></ns2:getNotificacionResponse>");

        mockClient
                .sendRequest(withPayload(requestPayload))
                .andExpect(noFault())
                .andExpect(payload(responsePayload));

    }
    
}
