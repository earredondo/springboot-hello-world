CREATE TABLE Destinatario
(
correo VARCHAR(127),
nombre VARCHAR(127),
grado_academico VARCHAR(31) NULL,
PRIMARY KEY(correo)
)

CREATE TABLE Estado
(
id_estado numeric(10) IDENTITY,
nombre VARCHAR(15) UNIQUE,
PRIMARY KEY(id_estado)
)

CREATE TABLE Notificacion
(
id_notificacion numeric(10) IDENTITY,
asunto VARCHAR(127),
fecha DATE,
id_estado numeric(10) references Estado(id_estado),
PRIMARY KEY(id_notificacion)
)

CREATE TABLE Archivo_adjunto
(
id_archivo numeric(10) IDENTITY,
nombre VARCHAR(127) UNIQUE,
contenido VARBINARY(MAX),
id_notificacion numeric(10) references Notificacion(id_notificacion),
PRIMARY KEY(id_archivo)
)

CREATE TABLE Destinatario_Notificacion
(
id_notificacion numeric(10) references Notificacion(id_notificacion),
correo VARCHAR(127) references Destinatario(correo),
tipo_relacion VARCHAR(15),
PRIMARY KEY(id_notificacion, correo)
)

CREATE TABLE Rol
(
id_rol numeric(10) IDENTITY,
nombre VARCHAR(15),
PRIMARY KEY(id_rol)
)

CREATE TABLE Grupos_de_control
(
id_grupo numeric(10) IDENTITY,
nombre VARCHAR(127) UNIQUE,
id_rol numeric(10) references Rol(id_rol),
PRIMARY KEY(id_grupo)
)

CREATE TABLE Bitacora
(
id numeric(10) IDENTITY, 
usuario VARCHAR(15),
accion VARCHAR(511),
argumentos VARCHAR(2047),
resultado VARCHAR(511),
fecha DATETIME,
PRIMARY KEY(id)
)

CREATE TABLE Tipo_plantilla
(
id_tipo_plantilla numeric(10) IDENTITY,
nombre VARCHAR(127) UNIQUE,
contenido VARBINARY(MAX),
PRIMARY KEY(id_tipo_plantilla)
)

CREATE TABLE Plantilla
(
id_plantilla numeric(10) IDENTITY,
id_notificacion numeric(10) references Notificacion(id_notificacion),
id_tipo_plantilla numeric(10) references Tipo_plantilla(id_tipo_plantilla),
PRIMARY KEY(id_plantilla)
)

CREATE TABLE Tipo_metadato
(
id_tipo_metadato numeric(10) IDENTITY,
nombre VARCHAR(63),
tipo CHAR(1),
id_tipo_plantilla numeric(10) references Tipo_plantilla(id_tipo_plantilla),
PRIMARY KEY(id_tipo_metadato)
)

CREATE TABLE Metadato
(
id_metadato numeric(10) IDENTITY,
valor VARCHAR(2047),
id_tipo_metadato numeric(10) references Tipo_metadato(id_tipo_metadato),
id_plantilla numeric(10) references Plantilla(id_plantilla),
PRIMARY KEY(id_metadato)
)

CREATE TABLE Valor_predefinido
(
id_valor numeric(10) IDENTITY,
valor VARCHAR(2047),
id_tipo_metadato numeric(10) references Tipo_metadato(id_tipo_metadato),
PRIMARY KEY(id_valor)
)