CREATE TABLE Destinatario
(
id_destinatario numeric(10) IDENTITY,
nombre VARCHAR(127),
grado_academico VARCHAR(31),
correo VARCHAR(127),
PRIMARY KEY(id_destinatario)
)

CREATE TABLE Notificacion
(
id_notificacion numeric(10) IDENTITY,
folio VARCHAR(15),
destinatario numeric(10) references Destinatario(id_destinatario),
situacion VARCHAR(511),
accion_requerida VARCHAR(511),
asunto VARCHAR(127),
copia_para numeric(10) references Destinatario(id_destinatario) NULL,
fecha DATE NULL,
estatus VARCHAR(31),
PRIMARY KEY(id_notificacion)
)

CREATE TABLE Administrador_sistema
(
clave_empleado VARCHAR(15),
PRIMARY KEY(clave_empleado)
)