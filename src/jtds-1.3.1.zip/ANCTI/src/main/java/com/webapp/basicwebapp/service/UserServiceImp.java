/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webapp.basicwebapp.service;

/**
 *
 * @author edgar
 */
import com.webapp.basicwebapp.dao.GenericDao;
import com.webapp.basicwebapp.pojos.UserTbl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserServiceImp implements UserService {
   
    @Autowired
    private GenericDao<UserTbl, Long> userDao;
 
    @Autowired
    public void setDao(GenericDao<UserTbl, Long> genericDao) {
        this.userDao=genericDao;
    }

   @Transactional
   public void save(UserTbl user) {
       userDao.create(user);
   }

   @Transactional(readOnly = true)
   public List<UserTbl> list() {
       return userDao.getAll();
   }
}