/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webapp.basicwebapp.service;

/**
 *
 * @author edgar
 */
import com.webapp.basicwebapp.dao.GenericDao;
import com.webapp.basicwebapp.dao.UserDao;
import com.webapp.basicwebapp.pojos.UserTbl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImp extends GenericServiceImp<UserTbl, Long>
        implements UserService {
   
    private UserDao userDao;
    public UserServiceImp(){
 
    }
    @Autowired
    public UserServiceImp(
            @Qualifier("userDaoImp") GenericDao<UserTbl, Long> genericDao) {
        super(genericDao);
        this.userDao = (UserDao) genericDao;
    }
}