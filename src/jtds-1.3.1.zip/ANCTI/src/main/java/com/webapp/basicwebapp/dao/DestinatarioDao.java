/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webapp.basicwebapp.dao;

import com.webapp.basicwebapp.pojos.Destinatario;

/**
 *
 * @author T42719
 */
public interface DestinatarioDao extends GenericDao<Destinatario, Long>{
    
}
