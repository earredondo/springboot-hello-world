/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.presentacion;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import mx.org.banxico.dgcar.ancti.pojos.Destinatario;
import mx.org.banxico.dgcar.ancti.pojos.Notificacion;
import mx.org.banxico.dgcar.ancti.servicios.NotificacionService;
import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.primefaces.context.RequestContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 *
 * @author T42719
 */
@Scope(value = "session")
@Component(value = "notificacionBean")
@ELBeanName(value = "notificacionBean")
@Join(path = "/", to = "/Notificaciones.jsf")
public class ControladorNotificaciones implements Serializable{
    
    @Autowired(required = true)
    private NotificacionService notificacionService;
    private List<Notificacion> notificaciones;
    private long id;
    private String folio;
    private String asunto;
    private Destinatario destinatario;
    private String situacion;
    private String accionRequerida;
    private Destinatario cc;
    private String estatus;
    private String fecha;

    @PostConstruct
    public void init(){
        this.estatus = "borrador";
    }
    
    /**
     *
     * @return
     */
    public List<Notificacion> getNotificaciones() {return this.notificaciones == null ? this.notificaciones = notificacionService.getAll() : this.notificaciones;}

    /**
     *
     * @param notificaciones
     */
    public void setNotificaciones(List<Notificacion> notificaciones) {this.notificaciones = notificaciones;}
    
    /**
     *
     * @param notificacion
     */
    public void eliminarNotificacion(Notificacion notificacion){
        notificacionService.remove(notificacion);
        notificaciones.remove(notificacion);
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Info", "La notificación ha sido eliminada"));
    }

    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * @return the folio
     */
    public String getFolio() {
        return folio;
    }

    /**
     * @param folio the folio to set
     */
    public void setFolio(String folio) {
        this.folio = folio;
    }

    /**
     * @return the asunto
     */
    public String getAsunto() {
        return asunto;
    }

    /**
     * @param asunto the asunto to set
     */
    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }

    /**
     * @return the Destinatario
     */
    public Destinatario getDestinatario() {
        return destinatario;
    }

    /**
     * @param destinatario the Destinatario to set
     */
    public void setDestinatario(Destinatario destinatario) {
        this.destinatario = destinatario;
    }

    /**
     * @return the situacion
     */
    public String getSituacion() {
        return situacion;
    }

    /**
     * @param situacion the situacion to set
     */
    public void setSituacion(String situacion) {
        this.situacion = situacion;
    }

    /**
     * @return the accionRequerida
     */
    public String getAccionRequerida() {
        return accionRequerida;
    }

    /**
     * @param accionRequerida the accionRequerida to set
     */
    public void setAccionRequerida(String accionRequerida) {
        this.accionRequerida = accionRequerida;
    }

    /**
     * @return the cc
     */
    public Destinatario getCc() {
        return cc == null ? new Destinatario() : cc;
    }

    /**
     * @param cc the cc to set
     */
    public void setCc(Destinatario cc) {
        this.cc = cc;
    }

    /**
     * @return the estatus
     */
    public String getEstatus() {
        return estatus;
    }

    /**
     * @param estatus the estatus to set
     */
    public void setEstatus(String estatus) {
        this.estatus = estatus;
    }

    /**
     * @return the fecha
     */
    public String getFecha() {
        return fecha;
    }

    /**
     * @param fecha the fecha to set
     */
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
    public void crearNotificacion(){
        try{
            System.out.println("Iniciando registro de " + this);
            Notificacion notificacion = new Notificacion(this.id, this.destinatario, this.cc, this.folio, this.situacion, this.accionRequerida, this.asunto, new Date(), this.estatus);
            notificacionService.create(notificacion);
            notificaciones.add(notificacion);
            RequestContext.getCurrentInstance().execute("PF('modalRegistrarNotificacion').hide()");
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Info", "Se ha registrado la notificación correctamente."));
        }catch(Exception e){
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", " Ocurrió un error durante la transacción."));
            System.out.println(e.getMessage());
        }
    }
    
    public void enviarCorreo(){
        System.out.println("Mensajes");
        FacesContext context = FacesContext.getCurrentInstance();
        context.addMessage(null, new FacesMessage("Successful",  "Your message: " + "Hola") );
        context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", " Ocurrió un error durante la transacción."));
        //notificacionService.sendEmail();
    }
}
