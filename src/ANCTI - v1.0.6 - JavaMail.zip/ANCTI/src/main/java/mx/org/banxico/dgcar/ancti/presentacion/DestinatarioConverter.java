/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.presentacion;

import java.util.Set;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;
import mx.org.banxico.dgcar.ancti.pojos.Destinatario;
import mx.org.banxico.dgcar.ancti.servicios.DestinatarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 *
 * @author T42719
 */
@Component(value = "destinatarioConverter")
public class DestinatarioConverter implements Converter {
    
    @Autowired(required = true)
    private DestinatarioService service;
 
    @Override
    public Object getAsObject(FacesContext fc, UIComponent uic, String value) {
        System.out.println("Valor: " + value);
        if(value != null && value.trim().length() > 0) {
            try {
                for(Destinatario destinatario : service.getAll()){
                    if (Long.parseLong(value) == destinatario.getIdDestinatario()) {
                        return destinatario;
                    }
                }
                System.out.println("No se encontro al destinatario");
                return null;
            } catch(Exception e) {
                throw new ConverterException(new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error de conversión", "No es un destinatario válido."));
            }
        }
        else {
            return null;
        }
    }
 
    @Override
    public String getAsString(FacesContext fc, UIComponent uic, Object object) {
        if(object != null) {
            return String.valueOf(((Destinatario) object).getIdDestinatario());
        }
        else {
            return null;
        }
    }   
}     