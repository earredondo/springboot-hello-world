/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.presentacion;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.validation.constraints.Pattern;
import mx.org.banxico.dgcar.ancti.pojos.Destinatario;
import mx.org.banxico.dgcar.ancti.pojos.Notificacion;
import mx.org.banxico.dgcar.ancti.servicios.DestinatarioService;
import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.primefaces.context.RequestContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 *
 * @author T42719
 */
@Scope(value = "session")
@Component(value = "destinatarioBean")
@ELBeanName(value = "destinatarioBean")
@Join(path = "/", to = "/Notificaciones.jsf")
public class ControladorDestinatarios implements Serializable{
    
    @Autowired(required = true)
    private DestinatarioService destinatarioService;
    private List<Destinatario> destinatarios;
    private long id;
    private String nombre;
    private String gradoAcademico;
    @Pattern(regexp = "\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}\\b", 
             message = "{email.invalid}")
    private String correo;

    /**
     * @return the destinatarios
     */
    public List<Destinatario> getDestinatarios() {
        return this.destinatarios == null ? this.destinatarios = destinatarioService.getAll() : this.destinatarios;
    }

    /**
     * @param destinatarios the destinatarios to set
     */
    public void setDestinatarios(List<Destinatario> destinatarios) {
        this.destinatarios = destinatarios;
    }
    
    /**
     *
     * @param destinatario
     */
    public void eliminarDestinatario(Destinatario destinatario){
        try{
            destinatarioService.remove(destinatario);
            destinatarios.remove(destinatario);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Info", "El destinatario ha sido eliminado"));
        }catch(Exception e){
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "No puede eliminarse el destinatario mientras tenga notificaciones asociadas."));
        }
    }

    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the gradoAcademico
     */
    public String getGradoAcademico() {
        return gradoAcademico;
    }

    /**
     * @param gradoAcademico the gradoAcademico to set
     */
    public void setGradoAcademico(String gradoAcademico) {
        this.gradoAcademico = gradoAcademico;
    }

    /**
     * @return the correo
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * @param correo the correo to set
     */
    public void setCorreo(String correo) {
        this.correo = correo;
    }
    
    public void crearDestinatario(){
        System.out.println("Iniciando registro");
        try{
            Destinatario destinatario = new Destinatario(this.id, this.nombre, this.gradoAcademico, this.correo);
            destinatarioService.create(destinatario);
            destinatarios.add(destinatario);
            RequestContext.getCurrentInstance().execute("PF('modalRegistrarDestinatario').hide()");
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Info", "Se registró a " + this.nombre + " correctamente."));
        }catch(Exception e){
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Error durante la transacción."));
            System.out.println(e.getMessage());
        }
    }
    
    public List<Destinatario> completarDestinatario(String query) {
        List<Destinatario> destinatariosFiltrados = new ArrayList<>();
         
        for (Destinatario destinatario : this.destinatarios) {
            if(destinatario.getNombre().toLowerCase().startsWith(query.toLowerCase())) {
                destinatariosFiltrados.add(destinatario);
            }
        }    
        return destinatariosFiltrados;
    }
}
