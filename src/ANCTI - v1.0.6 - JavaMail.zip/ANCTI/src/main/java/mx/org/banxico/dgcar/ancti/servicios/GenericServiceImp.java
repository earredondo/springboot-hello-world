/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.servicios;

import mx.org.banxico.dgcar.ancti.aspectos.Loggable;
import mx.org.banxico.dgcar.ancti.dao.GenericDao;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


/**
 *
 * @author edgar
 * @param <E>
 * @param <K>
 */
@Loggable
@Service
public abstract class GenericServiceImp<E, K> 
        implements GenericService<E, K> {
 
    private GenericDao<E, K> genericDao;
    @Autowired
    private JavaMailSender emailSender;

    /**
     *
     * @param genericDao
     */
    public GenericServiceImp(GenericDao<E,K> genericDao) {
        this.genericDao=genericDao;
    }
 
    /**
     *
     */
    public GenericServiceImp() {
    }
 
    /**
     *
     * @param entity
     */
    @Override
    //@Loggable
    @Transactional(propagation = Propagation.REQUIRED)
    public void saveOrUpdate(E entity) {
        genericDao.saveOrUpdate(entity);
    }
 
    /**
     *
     * @return
     */
    @Override
    //@Loggable
    @Transactional(propagation = Propagation.REQUIRED/*, readOnly = true*/)
    public List<E> getAll() {
        return genericDao.getAll();
    }
 
    /**
     *
     * @param id
     * @return
     */
    @Override
    //@Loggable
    @Transactional(propagation = Propagation.REQUIRED/*, readOnly = true*/)
    public E find(K id) {
        return genericDao.find(id);
    }
 
    /**
     *
     * @param entity
     */
    @Override
    //@Loggable
    @Transactional(propagation = Propagation.REQUIRED)
    public void create(E entity){
        genericDao.create(entity);
    }
 
    /**
     *
     * @param entity
     */
    @Override
    //@Loggable
    @Transactional(propagation = Propagation.REQUIRED)
    public void update(E entity) {
        genericDao.update(entity);
    }
 
    /**
     *
     * @param entity
     */
    @Override
    //@Loggable
    @Transactional(propagation = Propagation.REQUIRED)
    public void remove(E entity) {
        genericDao.remove(entity);
    }
    
    @Override
    public void sendEmail(){
        System.out.println("Enviando mensaje");
        String to = "edgar.arredondo.basurto@gmail.com";
        String subject = "Servicio social";
        String text = "Este es un mensaje de servicio social";
        SimpleMailMessage message = new SimpleMailMessage(); 
        message.setTo(to); 
        message.setSubject(subject); 
        message.setText(text);
        emailSender.send(message);
        System.out.println("Mensaje enviado");
    }
}