/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.config;

/**
 *
 * @author edgar
 */
import java.util.Properties;
import mx.org.banxico.dgcar.ancti.aspectos.Aspecto;
import mx.org.banxico.dgcar.ancti.pojos.GruposDeControl;
import mx.org.banxico.dgcar.ancti.pojos.Bitacora;
import mx.org.banxico.dgcar.ancti.pojos.Destinatario;
import mx.org.banxico.dgcar.ancti.pojos.Notificacion;
import mx.org.banxico.dgcar.ancti.pojos.SesionUsuario;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

/**
 * @author imssbora
 */
@Configuration
@EnableAspectJAutoProxy
@EnableTransactionManagement
@ComponentScans(value = {
    @ComponentScan("mx.org.banxico.dgcar.ancti.dao"),
    @ComponentScan("mx.org.banxico.dgcar.ancti.servicios"),
    @ComponentScan("mx.org.banxico.dgcar.ancti.presentacion")})
public class AppConfig {

    /**
     *
     * @return
     */
    @Bean
    public LocalSessionFactoryBean getSessionFactory() {
        LocalSessionFactoryBean factoryBean = new LocalSessionFactoryBean();
        factoryBean.setConfigLocation(new ClassPathResource("hibernate.cfg.xml"));
        factoryBean.setAnnotatedClasses(new Class[]{GruposDeControl.class, Destinatario.class, Notificacion.class, Bitacora.class});
        return factoryBean;
    }

    /**
     *
     * @return
     */
    @Bean
    public HibernateTransactionManager getTransactionManager() {
        HibernateTransactionManager transactionManager = new HibernateTransactionManager();
        transactionManager.setSessionFactory(getSessionFactory().getObject());
        return transactionManager;
    }

    /**
     *
     * @return
     */
    @Bean
    public Aspecto getAspecto() {
        return new Aspecto();
    }
    
    /**
     *
     * @return
     */
    @Bean
    public SesionUsuario getSesion(){
        return new SesionUsuario();
    }
    
    @Bean
    public JavaMailSender getJavaMailSender() {
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        /*
        mailSender.setHost("smtp.gmail.com");
        mailSender.setPort(587);
        mailSender.setProtocol("smtp");
        mailSender.setUsername("edgar.arredondo.basurto@gmail.com");
        mailSender.setPassword("Alkaline3.-");
        */
        /*
        mailSender.setHost("smtp-mail.outlook.com");
        mailSender.setPort(587);
        mailSender.setProtocol("smtp");
        mailSender.setUsername("edgar_arredondo@outlook.com");
        mailSender.setPassword("Alkaline3.-");
        
        Properties props = mailSender.getJavaMailProperties();
        props.setProperty("mail.smtp.starttls.enable", "true");
        //props.setProperty("mail.smtp.ssl.enable", "false");
        //props.setProperty("mail.smtp.ssl.trust", "*");
        props.setProperty("mail.smtp.auth", "true");
        props.put("mail.debug", "true");
        props.put("mail.smtp.quitwait", "false");
        */
        
        mailSender.setHost("BMMAIL");
        mailSender.setPort(25);
        mailSender.setProtocol("smtp");
        mailSender.setUsername("CorreoServicio@banxico.org.mx");
        //mailSender.setPassword("Alkaline3.-");
        
        Properties props = mailSender.getJavaMailProperties();
        props.put("mail.debug", "true");

        return mailSender;
    }

}
