/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.presentacion;

import mx.org.banxico.dgcar.ancti.pojos.GruposDeControl;
import mx.org.banxico.dgcar.ancti.servicios.GruposDeControlService;
import java.io.Serializable;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import mx.org.banxico.dgcar.ancti.pojos.SesionUsuario;
import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.primefaces.context.RequestContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 *
 * @author T42719
 */
//@ManagedBean(name = "admin")
//@ViewScoped
@Scope(value = "session")
@Component(value = "grupoAdmin")
@ELBeanName(value = "grupoAdmin")
@Join(path = "/controlacceso", to = "/ControlDeAcceso.jsf")
public class ControladorAdministradores implements Serializable{
    
    @Autowired(required = true)
    private GruposDeControlService grupoService;
    @Autowired
    private SesionUsuario sesion;
    private List<GruposDeControl> grupos;
    private String nombre;
    private String tipo;
    
    /**
     *
     * @return
     */
    public String getNombre() {return this.nombre;}

    /**
     *
     * @param nombre
     */
    public void setNombre(String nombre) {this.nombre = nombre;}

    /**
     *
     * @return
     */
    public String getTipo() {return this.tipo;}

    /**
     *
     * @param tipo
     */
    public void setTipo(String tipo) {this.tipo = tipo;}

    /**
     *
     * @return
     */
    public List<GruposDeControl> getGrupos() {return this.grupos == null ? this.grupos = grupoService.getAll() : this.grupos;}

    /**
     *
     * @param grupos
     */
    public void setGrupos(List<GruposDeControl> grupos) {this.grupos = grupos;}
    
    /**
     *
     */
    public void registrarAdministrador(){
        try{
            System.out.println("Iniciando registro");
            GruposDeControl grupo = new GruposDeControl(this.nombre, this.tipo);
            grupoService.create(grupo);
            grupos.add(grupo);
            sesion.setUsuario("T9000");
            RequestContext.getCurrentInstance().execute("PF('modalRegistrarAdministrador').hide()");
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Info", "Se ha registrado a el " + this.tipo + " " + this.nombre + " como administrador."));
        }catch(Exception e){
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", this.nombre + " ya existe como administrador."));
            System.out.println(e.getMessage());
        }
    }
    
    /**
     *
     * @param grupo
     */
    public void eliminarGrupo(GruposDeControl grupo){
        grupoService.remove(grupo);
        grupos.remove(grupo);
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Info", grupo.getTipo() + " " + grupo.getNombre() + " ha sido eliminado"));
    }
}
