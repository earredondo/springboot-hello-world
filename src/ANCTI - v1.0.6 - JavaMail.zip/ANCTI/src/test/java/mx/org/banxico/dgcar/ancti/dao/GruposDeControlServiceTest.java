/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.dao;

import java.util.ArrayList;
import java.util.List;
import mx.org.banxico.dgcar.ancti.config.AppConfig;
import mx.org.banxico.dgcar.ancti.pojos.GruposDeControl;
import mx.org.banxico.dgcar.ancti.servicios.GruposDeControlService;
import org.junit.After;
import org.junit.Assert;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

/**
 *
 * @author T42719
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=AppConfig.class, loader=AnnotationConfigContextLoader.class)
public class GruposDeControlServiceTest {
    
    @Autowired(required = true)
    private GruposDeControlService grupoService;
    private List<GruposDeControl> grupos;
    
    public GruposDeControlServiceTest(){
    }
    
    @Before
    public void setUp() {
        grupos = new ArrayList();
        grupos.add(new GruposDeControl("T99999", "Usuario"));
        grupos.add(new GruposDeControl("T99998", "Usuario"));
        grupos.add(new GruposDeControl("T99997", "Usuario"));
        grupos.add(new GruposDeControl("T99996", "Usuario"));
        grupos.add(new GruposDeControl("T99995", "Usuario"));
        
        for(GruposDeControl grupo : grupos){
            grupoService.create(grupo);
        }
    }
    
    @After
    public void tearDown(){
        for(GruposDeControl grupo : grupos){
            grupoService.remove(grupo);
        }
    }

    @Test
    public void testFind() {
        GruposDeControl grupo = new GruposDeControl("T99999", "Usuario");
        GruposDeControl grupo2 = grupoService.find("T99999");
        assertEquals(grupo2, grupo);
    }
    
    @Test
    public void testRemove(){
        GruposDeControl grupo = new GruposDeControl("T99998", "Usuario");
        try{
            grupoService.remove(grupo);
        }catch(Exception e){
            Assert.fail("Error al borrar la informacion");
        }
        grupos.remove(grupo);
        Assert.assertTrue(true);
        
    }
    
    @Test
    public void testCreate(){
        GruposDeControl grupo = new GruposDeControl("T99994", "Usuario");
        try{
            grupoService.create(grupo);
        }catch(Exception e){
            Assert.fail("Error al persistir la informacion");
        }
        grupos.add(grupo);
        Assert.assertTrue(true);
    }
    
    @Test
    public void testSaveOrUpdate(){
        GruposDeControl grupo = new GruposDeControl("T99993", "Usuario");
        try{
            grupoService.saveOrUpdate(grupo);
        }catch(Exception e){
            Assert.fail("Error al persistir la informacion");
        }
        grupos.add(grupo);
        Assert.assertTrue(true);
    }
    
    @Test
    public void testGetAll(){
        List<GruposDeControl> gr = grupoService.getAll();
        Assert.assertTrue(gr.containsAll(grupos));
    }
    /*
    @Test
    public void testSendEmail(){
        try{
            grupoService.sendEmail();
            Assert.assertTrue(true);
        }catch(Exception e){
            e.printStackTrace();
            Assert.fail("Error al enviar el correo electrónico");
        }
    }
    */
}
