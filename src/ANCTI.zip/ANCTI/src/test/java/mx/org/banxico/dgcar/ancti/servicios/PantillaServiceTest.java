/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.servicios;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import junit.framework.Assert;
import mx.org.banxico.dgcar.ancti.config.AppConfig;
import mx.org.banxico.dgcar.ancti.pojos.Plantilla;
import org.apache.poi.util.IOUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

/**
 *
 * @author T42719
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=AppConfig.class, loader=AnnotationConfigContextLoader.class)
public class PantillaServiceTest {
    
    @Autowired(required = true)
    private PlantillaService plantillaService;
    
    @Test
    public void testCreate(){
        /*
        String filePath = "H:\\Edgar\\ANCTI\\Proyecto\\plantillaNotificaciones.xlsx";
        try {
            File archivo = new File(filePath);
            FileInputStream fis = new FileInputStream(archivo);
            Plantilla plantilla = new Plantilla();
            plantilla.setNombre(archivo.getName());
            plantilla.setContenido(IOUtils.toByteArray(fis));
            plantillaService.create(plantilla);
            Assert.assertTrue(true);
        } catch (IOException ioe) {
            ioe.printStackTrace();
            Assert.fail("No se encontró el archivo especificado");
        }
        */
        Assert.assertTrue(true);
    }
    
    
}
