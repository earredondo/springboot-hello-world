/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.servicios;

import mx.org.banxico.dgcar.ancti.pojos.Notificacion;

/**
 *
 * @author edgar
 */
public interface NotificacionService extends GenericService<Notificacion,Long>{
    public void importarNotificacionesExcel(String filePath);
}
