/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.servicios;

import java.util.List;
import mx.org.banxico.dgcar.ancti.dao.GruposDeControlDao;
import mx.org.banxico.dgcar.ancti.dao.GenericDao;
import mx.org.banxico.dgcar.ancti.pojos.GruposDeControl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author edgar
 */
@Service
public class GruposDeControlServiceImp extends GenericServiceImp<GruposDeControl, String>
        implements GruposDeControlService {
   
    private GruposDeControlDao administradorDao;

    /**
     *
     */
    public GruposDeControlServiceImp(){
 
    }

    /**
     *
     * @param genericDao
     */
    @Autowired
    public GruposDeControlServiceImp(
             /*@Qualifier("admininstradorSistemaDaoImp") */GenericDao<GruposDeControl, String> genericDao) {
        super(genericDao);
        this.administradorDao = (GruposDeControlDao) genericDao;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED/*, readOnly = true*/)
    public List<GruposDeControl> findByType(String nombre, String tipo) {
        return this.administradorDao.findByType(nombre, tipo);
    }
}