/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.presentacion;

import java.io.IOException;
import mx.org.banxico.dgcar.ancti.pojos.GruposDeControl;
import mx.org.banxico.dgcar.ancti.servicios.GruposDeControlService;
import java.io.Serializable;
import java.util.Enumeration;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import mx.org.banxico.dgcar.ancti.pojos.Rol;
import mx.org.banxico.dgcar.ancti.pojos.SesionUsuario;
import mx.org.banxico.dgcar.ancti.servicios.RolService;
import org.banxico.ds.digest.DigestSSPServer;
import org.banxico.ds.security.Group;
import org.banxico.ds.security.Principal;
import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.primefaces.context.RequestContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 *
 * @author T42719
 */
@Scope(value = "session")
@Component(value = "grupoAdmin")
@ELBeanName(value = "grupoAdmin")
@Join(path = "/controlacceso", to = "/ControlDeAcceso.jsf")
public class ControladorAdministradores implements Serializable{
    
    @Autowired(required = true)
    private GruposDeControlService grupoService;
    @Autowired
    private SesionUsuario sesion;
    @Autowired(required = true)
    private RolService rolService;
    private List<GruposDeControl> grupos;
    private GruposDeControl administrador;
    private List<Rol> roles;
    
    @PostConstruct
    public void init(){
        this.administrador = new GruposDeControl();
    }

    /**
     *
     * @return
     */
    public List<GruposDeControl> getGrupos() {return this.grupos == null ? this.grupos = grupoService.getAll() : this.grupos;}

    /**
     *
     * @param grupos
     */
    public void setGrupos(List<GruposDeControl> grupos) {this.grupos = grupos;}
    
    /**
     *
     */
    public void registrarAdministrador(){
        try{
            System.out.println("******************************************Iniciando registro");
            grupoService.create(this.administrador);
            grupos.add(this.administrador);
            //sesion.setUsuario("T9000");
            RequestContext.getCurrentInstance().execute("PF('modalRegistrarAdministrador').hide()");
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Info", "Se ha registrado a el " + this.administrador.getTipo() + " " + this.administrador.getNombre() + " como administrador."));
        }catch(Exception e){
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", this.administrador.getNombre() + " ya existe como administrador."));
            System.out.println(e.getMessage());
        }
    }
    
    /**
     *
     * @param grupo
     */
    public void eliminarGrupo(GruposDeControl grupo){
        grupoService.remove(grupo);
        grupos.remove(grupo);
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Info", grupo.getTipo() + " " + grupo.getNombre() + " ha sido eliminado"));
    }

    /**
     * @return the administrador
     */
    public GruposDeControl getAdministrador() {
        return administrador;
    }

    /**
     * @param administrador the administrador to set
     */
    public void setAdministrador(GruposDeControl administrador) {
        this.administrador = administrador;
    }
    
    public void esAdministrador(){
        FacesContext facesContext = FacesContext.getCurrentInstance();
        HttpSession session = (HttpSession) facesContext.getExternalContext().getSession(true);
        /*
        Enumeration keys = session.getAttributeNames();
        System.out.println("*****************Variables de sesion");
        while (keys.hasMoreElements())
        {
            String key = (String)keys.nextElement();
            System.out.println(key + ": " + session.getValue(key));
        }
        System.out.println("**********************");
        */
        
        DigestSSPServer dg = (DigestSSPServer)session.getAttribute("org.banxico.ds.saabm.fs.secctxt");
        Principal pr = dg.getAuthorizationPrincipal();
        System.out.println("Usuario: " + pr.getUserName());
        System.out.println("Grupos:");
        Group[] grupos = pr.getGroups();
        boolean estaAutorizado = false;
        boolean rol = false;
        List<GruposDeControl> gdc;
        GruposDeControl usuario = null;
        for(Group grupo : grupos){
            gdc = this.grupoService.findByType(grupo.getDisplayName().split("@")[0], "grupo");
            if(gdc.size() == 1){
                estaAutorizado = true;
                rol = "administrador".equals(gdc.get(0).getRol().getNombre().toLowerCase());
                usuario = gdc.get(0);
            }
        }
        gdc = this.grupoService.findByType(pr.getUserName(), "usuario");
        if(gdc.size() == 1){
            estaAutorizado = true;
            rol = "administrador".equals(gdc.get(0).getRol().getNombre().toLowerCase());
            usuario = gdc.get(0);
        }
        if(estaAutorizado){
            sesion.setUsuario(usuario);
            sesion.setClaveEmpleado(pr.getUserName());
            System.out.println("Usuario autorizado: " + sesion);
        }else{
            try{
            facesContext.getExternalContext().redirect("http://archivo/sitio/atac/_layouts/AccessDenied.aspx");
            }catch(IOException ioe){
                ioe.printStackTrace();
            }
            System.out.println("Usuario" + pr.getUserName() + " no autorizado");
        }
    }

    /**
     * @return the roles
     */
    public List<Rol> getRoles() {
        return this.rolService.getAll();
    }

    /**
     * @param roles the roles to set
     */
    public void setRoles(List<Rol> roles) {
        this.roles = roles;
    }
}
