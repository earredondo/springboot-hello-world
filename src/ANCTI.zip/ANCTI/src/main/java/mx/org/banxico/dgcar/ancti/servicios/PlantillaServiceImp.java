/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.servicios;

import mx.org.banxico.dgcar.ancti.dao.PlantillaDao;
import mx.org.banxico.dgcar.ancti.dao.GenericDao;
import mx.org.banxico.dgcar.ancti.pojos.Plantilla;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author edgar
 */
@Service
public class PlantillaServiceImp extends GenericServiceImp<Plantilla, String>
        implements PlantillaService {
   
    private PlantillaDao plantillaDao;

    /**
     *
     */
    public PlantillaServiceImp(){
 
    }

    /**
     *
     * @param genericDao
     */
    @Autowired
    public PlantillaServiceImp(
             /*@Qualifier("admininstradorSistemaDaoImp") */GenericDao<Plantilla, String> genericDao) {
        super(genericDao);
        this.plantillaDao = (PlantillaDao) genericDao;
    }

}