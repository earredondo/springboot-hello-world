/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.presentacion;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import mx.org.banxico.dgcar.ancti.pojos.Destinatario;
import mx.org.banxico.dgcar.ancti.servicios.DestinatarioService;
import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.primefaces.context.RequestContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 *
 * @author T42719
 */
@Scope(value = "session")
@Component(value = "destinatarioBean")
@ELBeanName(value = "destinatarioBean")
@Join(path = "/", to = "/Notificaciones.jsf")
public class ControladorDestinatarios implements Serializable{
    
    @Autowired(required = true)
    private DestinatarioService destinatarioService;
    private List<Destinatario> destinatarios;
    private Destinatario destinatario;

    @PostConstruct
    public void init(){
        this.destinatario = new Destinatario();
    }
    
    /**
     * @return the destinatarios
     */
    public List<Destinatario> getDestinatarios() {
        return this.destinatarios == null ? this.destinatarios = destinatarioService.getAll() : this.destinatarios;
    }

    /**
     * @param destinatarios the destinatarios to set
     */
    public void setDestinatarios(List<Destinatario> destinatarios) {
        this.destinatarios = destinatarios;
    }
    
    /**
     *
     * @param destinatario
     */
    public void eliminarDestinatario(Destinatario destinatario){
        try{
            destinatarioService.remove(destinatario);
            destinatarios.remove(destinatario);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Info", "El destinatario ha sido eliminado"));
        }catch(Exception e){
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "No puede eliminarse el destinatario mientras tenga notificaciones asociadas."));
        }
    }

    public void crearDestinatario(){
        System.out.println("Iniciando registro");
        try{
            this.destinatarioService.create(destinatario);
            this.destinatarios.add(destinatario);
            RequestContext.getCurrentInstance().execute("PF('modalRegistrarDestinatario').hide()");
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Info", "Se registró a " + this.destinatario.getNombre() + " correctamente."));
            this.destinatario = new Destinatario();
        }catch(Exception e){
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Error durante la transacción."));
            System.out.println(e.getMessage());
        }
    }
    
    public List<Destinatario> completarDestinatario(String query) {
        List<Destinatario> destinatariosFiltrados = new ArrayList<>();
         
        for (Destinatario destinatario : this.destinatarios) {
            if(destinatario.getNombre().toLowerCase().startsWith(query.toLowerCase())) {
                destinatariosFiltrados.add(destinatario);
            }
        }    
        return destinatariosFiltrados;
    }

    /**
     * @return the destinatario
     */
    public Destinatario getDestinatario() {
        return destinatario;
    }

    /**
     * @param destinatario the destinatario to set
     */
    public void setDestinatario(Destinatario destinatario) {
        this.destinatario = destinatario;
    }
}
