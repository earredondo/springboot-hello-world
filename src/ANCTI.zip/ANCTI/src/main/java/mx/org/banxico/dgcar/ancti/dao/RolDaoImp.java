/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.dao;

import mx.org.banxico.dgcar.ancti.pojos.Rol;
import org.springframework.stereotype.Repository;

/**
 *
 * @author T42719
 */
@Repository
public class RolDaoImp extends GenericDaoImp<Rol, Long> implements RolDao{
    
}
