/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.servicios;

import mx.org.banxico.dgcar.ancti.dao.BitacoraDao;
import mx.org.banxico.dgcar.ancti.dao.GenericDao;
import mx.org.banxico.dgcar.ancti.pojos.Bitacora;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 *
 * @author edgar
 */
@Service
public class BitacoraServiceImp extends GenericServiceImp<Bitacora, Long>
        implements BitacoraService {
   
    private BitacoraDao bitacoraDao;

    /**
     *
     */
    public BitacoraServiceImp(){
 
    }

    /**
     *
     * @param genericDao
     */
    @Autowired
    public BitacoraServiceImp(
            @Qualifier("bitacoraDaoImp") GenericDao<Bitacora, Long> genericDao) {
        super(genericDao);
        this.bitacoraDao = (BitacoraDao) genericDao;
    }
}