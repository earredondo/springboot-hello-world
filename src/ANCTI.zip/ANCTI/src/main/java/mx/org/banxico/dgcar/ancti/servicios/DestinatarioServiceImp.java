/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.servicios;

import mx.org.banxico.dgcar.ancti.dao.DestinatarioDao;
import mx.org.banxico.dgcar.ancti.dao.GenericDao;
import mx.org.banxico.dgcar.ancti.pojos.Destinatario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 *
 * @author edgar
 */
@Service
public class DestinatarioServiceImp extends GenericServiceImp<Destinatario, Long>
        implements DestinatarioService {
   
    private DestinatarioDao destinatarioDao;

    /**
     *
     */
    public DestinatarioServiceImp(){
 
    }

    /**
     *
     * @param genericDao
     */
    @Autowired
    public DestinatarioServiceImp(
            @Qualifier("destinatarioDaoImp") GenericDao<Destinatario, Long> genericDao) {
        super(genericDao);
        this.destinatarioDao = (DestinatarioDao) genericDao;
    }
}