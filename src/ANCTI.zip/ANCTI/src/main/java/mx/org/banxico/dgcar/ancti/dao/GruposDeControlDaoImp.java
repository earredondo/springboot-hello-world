/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.dao;

import java.util.List;
import mx.org.banxico.dgcar.ancti.pojos.GruposDeControl;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

/**
 *
 * @author T42719
 */
@Repository
public class GruposDeControlDaoImp extends GenericDaoImp<GruposDeControl, String> implements GruposDeControlDao{

    public Session openSession(){
        return super.sessionFactory().openSession();
    }
    
    @Override
    public List<GruposDeControl> findByType(String nombre, String tipo) {
        try (Session sesion = openSession()) {
            return sesion.createQuery( "from " + daoType.getName() + " where lower(tipo) = '" + tipo.toLowerCase() +"' and lower(nombre) = '" + nombre.toLowerCase() + "'").list();
        }
    }
    
}
