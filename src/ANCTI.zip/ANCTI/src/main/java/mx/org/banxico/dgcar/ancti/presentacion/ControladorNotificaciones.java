/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.presentacion;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.net.URL;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import javax.validation.ConstraintViolationException;
import mx.org.banxico.dgcar.ancti.pojos.Destinatario;
import mx.org.banxico.dgcar.ancti.pojos.DestinatarioNotificacion;
import mx.org.banxico.dgcar.ancti.pojos.DestinatarioNotificacionId;
import mx.org.banxico.dgcar.ancti.pojos.Estado;
import mx.org.banxico.dgcar.ancti.pojos.Notificacion;
import mx.org.banxico.dgcar.ancti.pojos.Plantilla;
import mx.org.banxico.dgcar.ancti.servicios.EstadoService;
import mx.org.banxico.dgcar.ancti.servicios.NotificacionService;
import mx.org.banxico.dgcar.ancti.servicios.PlantillaService;
import mx.org.banxico.dgcar.ancti.utils.ExcelReader;
import mx.org.banxico.dgcar.ancti.utils.ExcelReaderImpl;
import org.banxico.ds.digest.DigestSSPServer;
import org.banxico.ds.security.Group;
import org.banxico.ds.security.Principal;
import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.primefaces.context.RequestContext;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.UploadedFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 *
 * @author T42719
 */
@Scope(value = "session")
@Component(value = "notificacionBean")
@ELBeanName(value = "notificacionBean")
@Join(path = "/", to = "/Notificaciones.jsf")
public class ControladorNotificaciones implements Serializable{
    
    @Autowired(required = true)
    private NotificacionService notificacionService;
    @Autowired(required = true)
    private PlantillaService plantillaService;
    @Autowired(required = true)
    private EstadoService estadoService;
    private List<Notificacion> notificaciones;
    private Notificacion notificacion;
    private StreamedContent contenido;
    private StreamedContent plantilla;
    private List<Destinatario> destinatarios;
    private List<Destinatario> conCopias;

    @PostConstruct
    public void init(){
        this.notificacion = new Notificacion();
        Estado borrador = this.estadoService.findByName("borrador");
        if(borrador == null){
            borrador = new Estado();
            borrador.setNombre("borrador");
            this.estadoService.create(borrador);
        }
        this.notificacion.setEstado(borrador);
    }
    
    /**
     *
     * @return
     */
    public List<Notificacion> getNotificaciones() {return this.notificaciones == null ? this.notificaciones = notificacionService.getAll() : this.notificaciones;}

    /**
     *
     * @param notificaciones
     */
    public void setNotificaciones(List<Notificacion> notificaciones) {this.notificaciones = notificaciones;}

    /**
     * @return the notificacion
     */
    public Notificacion getNotificacion() {
        return notificacion;
    }

    /**
     * @param notificacion the notificacion to set
     */
    public void setNotificacion(Notificacion notificacion) {
        this.notificacion = notificacion;
    }
    
    /**
     *
     * @param notificacion
     */
    public void eliminarNotificacion(Notificacion notificacion){
        notificacionService.remove(notificacion);
        notificaciones.remove(notificacion);
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Info", "La notificación ha sido eliminada"));
    }

    public void crearNotificacion(){
        try{
            this.notificacion.setFecha(new Date());
            System.out.println("Iniciando registro de " + this.notificacion);
            for(Destinatario destinatario : this.destinatarios){
                this.notificacion.addDestinatario(destinatario, "destinatario");
            }
            for(Destinatario cc : this.conCopias){
                this.notificacion.addDestinatario(cc, "con copia");
            }
            this.notificacionService.saveOrUpdate(this.notificacion);
            this.notificaciones.add(this.notificacion);
            RequestContext.getCurrentInstance().execute("PF('modalRegistrarNotificacion').hide()");
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Info", "Se ha registrado la notificación correctamente."));
        }catch(Exception e){
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", " Ocurrió un error durante la transacción."));
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
    }
    
    public void enviarCorreo(){
        
        
    }
    
    public void importarExcel(FileUploadEvent event){
        UploadedFile file = event.getFile();
        try{
            ExcelReader reader = new ExcelReaderImpl();
            InputStream is = file.getInputstream();
            List<Notificacion> notificaciones = reader.readObjects(file.getFileName(), is);
            for(Notificacion notificacion : notificaciones){
                System.out.println("***" + notificacion);
                this.notificacionService.saveOrUpdate(notificacion);
                this.notificaciones.add(notificacion);
            }
            FacesMessage message = new FacesMessage("Succesful", file.getFileName() + " is uploaded.");
            FacesContext.getCurrentInstance().addMessage(null, message);
        }catch(IOException ioe){
        }catch(ConstraintViolationException cve){
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "El formato del correo electrónico es incorrecto");
            FacesContext.getCurrentInstance().addMessage(null, message);
        }
    }

    /**
     * @return the contenido
     */
    public StreamedContent getContenido() {
        try{
            ClassLoader classLoader = getClass().getClassLoader();
            File file = new File(classLoader.getResource("loading.gif").getFile());
            this.contenido = new DefaultStreamedContent(new FileInputStream(file), "image/png");
        }catch(FileNotFoundException fnfe){
            fnfe.printStackTrace();
        }
        return this.contenido;
    }

    /**
     * @param contenido the contenido to set
     */
    public void setContenido(StreamedContent contenido) {
        this.contenido = contenido;      
    }

    /**
     * @return the plantilla
     */
    public StreamedContent getPlantilla() {
        try{
            ClassLoader classLoader = getClass().getClassLoader();
            File file = new File(classLoader.getResource("plantillaNotificaciones.xlsx").getFile());
            FileInputStream fis = new FileInputStream(file);
            this.plantilla = new DefaultStreamedContent(fis, "text/plain", file.getName());
        }catch(IOException fnfe){
            fnfe.printStackTrace();
        }
        /* En caso de obtenerse de la base de datos*/
        /*
        Plantilla plantilla = this.plantillaService.find("plantillaNotificaciones.xlsx");
        ByteArrayInputStream bais = new ByteArrayInputStream(plantilla.getContenido());
        this.plantilla = new DefaultStreamedContent(bais, "application/vnd.ms-excel", plantilla.getNombre());
        */
        return this.plantilla;
    }

    /**
     * @param plantilla the plantilla to set
     */
    public void setPlantilla(StreamedContent plantilla) {
        this.plantilla = plantilla;
    }

    /**
     * @return the destinatarios
     */
    public List<Destinatario> getDestinatarios() {
        return destinatarios;
    }

    /**
     * @param destinatarios the destinatarios to set
     */
    public void setDestinatarios(List<Destinatario> destinatarios) {
        this.destinatarios = destinatarios;
    }

    /**
     * @return the conCopias
     */
    public List<Destinatario> getConCopias() {
        return conCopias;
    }

    /**
     * @param conCopias the conCopias to set
     */
    public void setConCopias(List<Destinatario> conCopias) {
        this.conCopias = conCopias;
    }

    
}
