/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.servicios;

import mx.org.banxico.dgcar.ancti.dao.GenericDao;
import mx.org.banxico.dgcar.ancti.dao.RolDao;
import mx.org.banxico.dgcar.ancti.pojos.Rol;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 *
 * @author edgar
 */
@Service
public class RolServiceImp extends GenericServiceImp<Rol, Long>
        implements RolService {
   
    private RolDao rolDao;

    /**
     *
     */
    public RolServiceImp(){
 
    }

    /**
     *
     * @param genericDao
     */
    @Autowired
    public RolServiceImp(
            @Qualifier("rolDaoImp") GenericDao<Rol, Long> genericDao) {
        super(genericDao);
        this.rolDao = (RolDao) genericDao;
    }
}