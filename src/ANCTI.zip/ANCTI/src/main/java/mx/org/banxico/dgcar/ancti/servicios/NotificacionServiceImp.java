/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.servicios;

import java.util.List;
import mx.org.banxico.dgcar.ancti.dao.GenericDao;
import mx.org.banxico.dgcar.ancti.dao.NotificacionDao;
import mx.org.banxico.dgcar.ancti.pojos.Notificacion;
import mx.org.banxico.dgcar.ancti.utils.ExcelReader;
import mx.org.banxico.dgcar.ancti.utils.ExcelReaderImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 *
 * @author edgar
 */
@Service
public class NotificacionServiceImp extends GenericServiceImp<Notificacion, Long>
        implements NotificacionService {
   
    private NotificacionDao notificacionDao;

    /**
     *
     */
    public NotificacionServiceImp(){
 
    }

    /**
     *
     * @param genericDao
     */
    @Autowired
    public NotificacionServiceImp(
            @Qualifier("notificacionDaoImp") GenericDao<Notificacion, Long> genericDao) {
        super(genericDao);
        this.notificacionDao = (NotificacionDao) genericDao;
    }
    
    @Override
    public void importarNotificacionesExcel(String filePath){
        ExcelReader reader = new ExcelReaderImpl();
        List<Notificacion> notificaciones = reader.readObjects(filePath);
        for(Notificacion notificacion : notificaciones){
            this.notificacionDao.create(notificacion);
        }
    }
}