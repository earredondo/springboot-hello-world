/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.aspectos;

import mx.org.banxico.dgcar.ancti.dao.BitacoraDao;
import java.util.Date;
import mx.org.banxico.dgcar.ancti.pojos.Bitacora;
import mx.org.banxico.dgcar.ancti.pojos.SesionUsuario;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author T42719
 */
@Aspect
public class Aspecto {
    
    @Autowired(required = true)
    private BitacoraDao bitacoraDao;
    @Autowired
    private SesionUsuario sesion;
    private static Logger loggerExceptions = LogManager.getLogger(Aspecto.class);
    
    /**
     *
     * @param pp
     * @return
     * @throws Throwable
     */
    @Around("execution(public * mx.org.banxico.dgcar.ancti.servicios.GenericServiceImp.*(..))")
    //@Around("@annotation(com.webapp.basicwebapp.aspectos.Loggable)")
    public Object crearBitacoraServicios(ProceedingJoinPoint pp) throws Throwable{
        Bitacora bitacora = new Bitacora();
        bitacora.setUsuario("T42719");  //El usuario debe obtenerse de la sesion
        bitacora.setAccion(pp.getSignature().toString());
        bitacora.setArgumentos(pp.getArgs().length > 0 ? pp.getArgs()[0].toString() : "");
        bitacora.setFecha(new Date());
        try {                  
            Object resultado = pp.proceed();
            bitacora.setResultado("OK");
            bitacoraDao.create(bitacora);
            System.out.println("Bitacora creada: " + bitacora);
            return resultado;
        }
        catch(Throwable e) {
            /* No es posible guardar la excepcion en la base de datos, guardar en archivos como alternativa */
            bitacora.setResultado(e.getMessage());
            loggerExceptions.error("\n" + bitacora);
            //System.out.println("SESION: " + sesion.getUsuario());
            e.printStackTrace();
            throw e;
        }
    }

    /**
     *
     * @param pp
     * @return
     */
    
    public Bitacora crearBitacora(JoinPoint pp){
        Bitacora bitacora = new Bitacora();
        bitacora.setUsuario("T42719");
        bitacora.setAccion(pp.getSignature().toString());
        bitacora.setArgumentos(pp.getArgs().length > 0 ? pp.getArgs()[0].toString() : "");
        bitacora.setFecha(new Date());
        return bitacora;
    }
}
