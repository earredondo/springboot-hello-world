/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.dao;

import java.util.List;
import mx.org.banxico.dgcar.ancti.pojos.Estado;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

/**
 *
 * @author T42719
 */
@Repository
public class EstadoDaoImp extends GenericDaoImp<Estado, Long> implements EstadoDao{
    
    public Session openSession(){
        return super.sessionFactory().openSession();
    }

    @Override
    public Estado findByName(String nombre) {
        try (Session sesion = openSession()) {
            List<Estado> resultado = sesion.createQuery( "from " + daoType.getName() + " where lower(nombre) = '" + nombre.toLowerCase() + "'").list();
            return resultado.size() > 0 ? resultado.get(0) : null;
        }
    }
    
}
