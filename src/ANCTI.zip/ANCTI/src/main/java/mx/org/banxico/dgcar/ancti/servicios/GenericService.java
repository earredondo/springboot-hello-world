/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.servicios;

import java.util.List;

/**
 *
 * @author edgar
 * @param <E>
 * @param <K>
 */
public interface GenericService<E, K> {

    /**
     *
     * @param entity
     */
    public void saveOrUpdate(E entity);

    /**
     *
     * @return
     */
    public List<E> getAll();

    /**
     *
     * @param id
     * @return
     */
    public E find(K id);

    /**
     *
     * @param entity
     */
    public void create(E entity);

    /**
     *
     * @param entity
     */
    public void update(E entity);

    /**
     *
     * @param entity
     */
    public void remove(E entity);
    
    public void sendEmail();
}