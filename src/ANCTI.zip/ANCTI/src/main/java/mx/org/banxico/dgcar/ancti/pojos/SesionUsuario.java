/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.pojos;

import org.springframework.context.annotation.Scope;

/**
 *
 * @author T42719
 */
@Scope(value = "session")
public class SesionUsuario {
    private GruposDeControl usuario;
    private String claveEmpleado;

    /**
     * @return the usuario
     */
    public GruposDeControl getUsuario() {
        return usuario;
    }

    /**
     * @param usuario the usuario to set
     */
    public void setUsuario(GruposDeControl usuario) {
        this.usuario = usuario;
    }

    /**
     * @return the claveEmpleado
     */
    public String getClaveEmpleado() {
        return claveEmpleado;
    }

    /**
     * @param claveEmpleado the claveEmpleado to set
     */
    public void setClaveEmpleado(String claveEmpleado) {
        this.claveEmpleado = claveEmpleado;
    }
    
    @Override
    public String toString(){
        return "{Clave de empleado: " + this.claveEmpleado + ", Grupo: " + this.usuario + "}";
    }
}
