/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.dao;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author T42719
 * @param <E>
 * @param <K>
 */
@SuppressWarnings("unchecked")
@Repository
public abstract class GenericDaoImp<E, K extends Serializable> 
        implements GenericDao<E, K> {
    @Autowired
    private SessionFactory sessionFactory;
     
    /**
     *
     */
    protected Class<? extends E> daoType;
     
    /**
    * By defining this class as abstract, we prevent Spring from creating 
    * instance of this class If not defined as abstract, 
    * getClass().getGenericSuperClass() would return Object. There would be 
    * exception because Object class does not hava constructor with parameters.
    */
    public GenericDaoImp() {
        Type t = getClass().getGenericSuperclass();
        ParameterizedType pt = (ParameterizedType) t;
        daoType = (Class) pt.getActualTypeArguments()[0];
    }
     
    /**
     *
     * @return
     */
    @Override
    public Session currentSession() {
        return sessionFactory.getCurrentSession();
    }
    
    public SessionFactory sessionFactory(){
        return sessionFactory;
    }
     
    /**
     *
     * @param entity
     */
    @Override
    public void create(E entity){
        currentSession().persist(entity);
    }
     
    /**
     *
     * @param entity
     */
    @Override
    public void saveOrUpdate(E entity) {
        currentSession().saveOrUpdate(entity);
    }
     
    /**
     *
     * @param entity
     */
    @Override
    public void update(E entity) {
        currentSession().saveOrUpdate(entity);
    }
     
    /**
     *
     * @param entity
     */
    @Override
    public void remove(E entity) {
        currentSession().delete(entity);
    }
     
    /**
     *
     * @param key
     * @return
     */
    @Override
    public E find(K key) {
        return (E) currentSession().get(daoType, key);
    }
     
    /**
     *
     * @return
     */
    @Override
    public List<E> getAll() {
        return currentSession().createQuery( "from " + daoType.getName() ).list();
        //return currentSession().createCriteria(daoType).list();
    }
}
