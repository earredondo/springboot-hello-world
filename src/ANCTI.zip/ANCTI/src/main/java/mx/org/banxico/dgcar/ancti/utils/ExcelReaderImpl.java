/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import mx.org.banxico.dgcar.ancti.pojos.Destinatario;
import mx.org.banxico.dgcar.ancti.pojos.Notificacion;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author T42719
 */
public class ExcelReaderImpl implements ExcelReader<Notificacion> {
    
    private Object getCellValue(Cell cell){
        switch(cell.getCellTypeEnum()){
            case STRING:
                return cell.getStringCellValue();
            case BOOLEAN:
                return cell.getBooleanCellValue();
            case NUMERIC:
                return cell.getNumericCellValue();
        }
        return null;
    }
    
    @Override
    public List readObjects(String fileName, InputStream stream){
        List<Notificacion> notificaciones = new ArrayList();
        Workbook workbook = null;
        try{
            workbook = getWorkbook(stream, fileName);
        }catch(IOException ioe){
            ioe.printStackTrace();
            return null;
        }
        Sheet hoja = workbook.getSheetAt(0);
        Iterator<Row> iterator = hoja.iterator();
        if(!checkHeaders(iterator))return null;
        while(iterator.hasNext()){
            Row nextRow = iterator.next();
            Iterator<Cell> cellIterator = nextRow.iterator();
            Notificacion notificacion = new Notificacion();
            Destinatario destinatario = new Destinatario();
            Destinatario copiaPara = new Destinatario();
            while(cellIterator.hasNext()){
                Cell nextCell = cellIterator.next();
                int columna = nextCell.getColumnIndex();
                switch(columna){
                    case 0:
                        notificacion.setFolio((String)getCellValue(nextCell));
                        break;
                    case 1:
                        destinatario.setGradoAcademico((String)getCellValue(nextCell));
                        break;
                    case 2:
                        destinatario.setNombre((String)getCellValue(nextCell));
                        break;
                    case 3:
                        destinatario.setCorreo((String)getCellValue(nextCell));
                        break;
                    case 4:
                        notificacion.setSituacion((String)getCellValue(nextCell));
                        break;
                    case 5:
                        notificacion.setAccionRequerida((String)getCellValue(nextCell));
                        break;
                    case 6:
                        notificacion.setAsunto((String)getCellValue(nextCell));
                        break;
                    case 7:
                        copiaPara.setNombre((String)getCellValue(nextCell));
                        break;
                    case 8:
                        copiaPara.setCorreo((String)getCellValue(nextCell));
                        break;
                }
            }
            /*notificacion.setDestinatarioByDestinatario(destinatario);
            notificacion.setDestinatarioByCopiaPara(copiaPara);
            notificacion.setFecha(new Date());
            notificacion.setEstatus("borrador");
            notificaciones.add(notificacion);*/
        }
        return notificaciones;
    }

    @Override
    public List readObjects(String filePath) {
        List<Notificacion> notificaciones = new ArrayList();
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(new File(filePath));
        } catch (IOException ioe) {
            ioe.printStackTrace();
            return null;
        }
        return readObjects(filePath, fis);
    }
    
    private Workbook getWorkbook(InputStream fis, String filePath) throws IOException{
        Workbook workbook = null;
        if(filePath.endsWith("xlsx")){
            workbook = new XSSFWorkbook((FileInputStream)fis);
        }else if(filePath.endsWith("xls")){
            workbook = new HSSFWorkbook((FileInputStream)fis);
        }else{
            throw new IllegalArgumentException("El archivo especificado no es un arhcivo de Excel.");
        }
        return workbook;
    }
    
    private boolean checkHeaders(Iterator<Row> iterator){
        if(!iterator.hasNext())return false;
        Row nextRow = iterator.next();
        Iterator<Cell> itera = nextRow.iterator();
        while(itera.hasNext()){
            Cell nextCell = itera.next();
            int columna = nextCell.getColumnIndex();
            switch(columna){
                case 0:
                    if(!"Folio".equals((String)getCellValue(nextCell))) return false;
                    break;
                case 1:
                    if(!"Título".equals((String)getCellValue(nextCell))) return false;
                    break;
                case 2:
                    if(!"Destinatario".equals((String)getCellValue(nextCell))) return false;
                    break;
                case 3:
                    if(!"Email".equals((String)getCellValue(nextCell))) return false;
                    break;
                case 4:
                    if(!"Situación".equals((String)getCellValue(nextCell))) return false;
                    break;
                case 5:
                    if(!"Acción requerida".equals((String)getCellValue(nextCell))) return false;
                    break;
                case 6:
                    if(!"Asunto".equals((String)getCellValue(nextCell))) return false;
                    break;
                case 7:
                    if(!"Con copia para".equals((String)getCellValue(nextCell))) return false;
                    break;
                case 8:
                    if(!"Email".equals((String)getCellValue(nextCell))) return false;
                    break;
            }
        }
        return true;
    }
    /*
    public static void main(String[] args) {
        ExcelReader reader = new ExcelReaderImpl();
        List<Notificacion> notificaciones = reader.readObjects("H:\\Edgar\\ANCTI\\Proyecto\\notificacionesPrueba.xlsx");
        for(Notificacion notificacion : notificaciones){
            System.out.println("***" + notificacion);
        }
        
    }
    */
}
