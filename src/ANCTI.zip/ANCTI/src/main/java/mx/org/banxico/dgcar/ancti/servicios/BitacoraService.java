/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.servicios;

import mx.org.banxico.dgcar.ancti.pojos.Bitacora;

/**
 *
 * @author edgar
 */
public interface BitacoraService extends GenericService<Bitacora,Long>{
    
}
