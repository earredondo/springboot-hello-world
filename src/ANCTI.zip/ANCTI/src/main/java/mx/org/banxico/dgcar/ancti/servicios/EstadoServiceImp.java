/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.org.banxico.dgcar.ancti.servicios;

import mx.org.banxico.dgcar.ancti.dao.EstadoDao;
import mx.org.banxico.dgcar.ancti.dao.GenericDao;
import mx.org.banxico.dgcar.ancti.pojos.Estado;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 *
 * @author edgar
 */
@Service
public class EstadoServiceImp extends GenericServiceImp<Estado, Long>
        implements EstadoService {
   
    private EstadoDao estadoDao;

    /**
     *
     */
    public EstadoServiceImp(){
 
    }

    /**
     *
     * @param genericDao
     */
    @Autowired
    public EstadoServiceImp(
            @Qualifier("estadoDaoImp") GenericDao<Estado, Long> genericDao) {
        super(genericDao);
        this.estadoDao = (EstadoDao) genericDao;
    }

    @Override
    public Estado findByName(String nombre) {
        return this.estadoDao.findByName(nombre);
    }
}