/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webapp.basicwebapp.dao;

/**
 *
 * @author edgar
 */

import com.webapp.basicwebapp.pojos.UserTbl;

public interface UserDao extends GenericDao<UserTbl, Long>{
    
}