/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webapp.basicwebapp.config;

/**
 *
 * @author edgar
 */
import com.webapp.basicwebapp.pojos.UserTbl;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.core.io.ClassPathResource;

/**
 * @author imssbora
 */
@Configuration
@EnableTransactionManagement
@ComponentScans(value = { @ComponentScan("com.webapp.basicwebapp.dao"),
      @ComponentScan("com.webapp.basicwebapp.service") })
public class AppConfig {


   @Bean
   public LocalSessionFactoryBean getSessionFactory() {
      LocalSessionFactoryBean factoryBean = new LocalSessionFactoryBean();
      factoryBean.setConfigLocation(new ClassPathResource("hibernate.cfg.xml"));
      factoryBean.setAnnotatedClasses(UserTbl.class);
      return factoryBean;
   }

   @Bean
   public HibernateTransactionManager getTransactionManager() {
      HibernateTransactionManager transactionManager = new HibernateTransactionManager();
      transactionManager.setSessionFactory(getSessionFactory().getObject());
      return transactionManager;
   }
}