/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webapp.basicwebapp.service;

import com.webapp.basicwebapp.dao.BitacoraDao;
import com.webapp.basicwebapp.dao.GenericDao;
import com.webapp.basicwebapp.pojos.Bitacora;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 *
 * @author edgar
 */
@Service
public class BitacoraServiceImp extends GenericServiceImp<Bitacora, Long>
        implements BitacoraService {
   
    private BitacoraDao bitacoraDao;
    public BitacoraServiceImp(){
 
    }
    @Autowired
    public BitacoraServiceImp(
            @Qualifier("bitacoraDaoImp") GenericDao<Bitacora, Long> genericDao) {
        super(genericDao);
        this.bitacoraDao = (BitacoraDao) genericDao;
    }
}