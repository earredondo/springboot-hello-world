/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webapp.basicwebapp.config;

/**
 *
 * @author edgar
 */
import com.webapp.basicwebapp.aspectos.Aspecto;
import com.webapp.basicwebapp.pojos.AdministradorSistema;
import com.webapp.basicwebapp.pojos.Bitacora;
import com.webapp.basicwebapp.pojos.Destinatario;
import com.webapp.basicwebapp.pojos.Notificacion;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.core.io.ClassPathResource;

/**
 * @author imssbora
 */
@Configuration
@EnableAspectJAutoProxy
@EnableTransactionManagement
@ComponentScans(value = {   @ComponentScan("com.webapp.basicwebapp.dao"),
                            @ComponentScan("com.webapp.basicwebapp.service"),
                            @ComponentScan("com.webapp.basicwebapp.presentacion")})
public class AppConfig {


   @Bean
   public LocalSessionFactoryBean getSessionFactory() {
      LocalSessionFactoryBean factoryBean = new LocalSessionFactoryBean();
      factoryBean.setConfigLocation(new ClassPathResource("hibernate.cfg.xml"));
      factoryBean.setAnnotatedClasses(new Class[]{AdministradorSistema.class, Destinatario.class, Notificacion.class, Bitacora.class});
      return factoryBean;
   }

   @Bean
   public HibernateTransactionManager getTransactionManager() {
      HibernateTransactionManager transactionManager = new HibernateTransactionManager();
      transactionManager.setSessionFactory(getSessionFactory().getObject());
      return transactionManager;
   }
   
   @Bean
   public Aspecto getAspecto(){
       return new Aspecto();
   }
}