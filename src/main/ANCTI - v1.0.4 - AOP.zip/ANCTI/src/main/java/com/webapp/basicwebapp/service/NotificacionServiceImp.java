/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webapp.basicwebapp.service;

import com.webapp.basicwebapp.dao.GenericDao;
import com.webapp.basicwebapp.dao.NotificacionDao;
import com.webapp.basicwebapp.pojos.Notificacion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 *
 * @author edgar
 */
@Service
public class NotificacionServiceImp extends GenericServiceImp<Notificacion, Long>
        implements NotificacionService {
   
    private NotificacionDao notificacionDao;
    public NotificacionServiceImp(){
 
    }
    @Autowired
    public NotificacionServiceImp(
            @Qualifier("notificacionDaoImp") GenericDao<Notificacion, Long> genericDao) {
        super(genericDao);
        this.notificacionDao = (NotificacionDao) genericDao;
    }
}