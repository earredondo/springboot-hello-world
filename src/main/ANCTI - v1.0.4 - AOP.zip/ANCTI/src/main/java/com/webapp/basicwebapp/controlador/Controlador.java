/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webapp.basicwebapp.controlador;

/**
 *
 * @author edgar
 */

//import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


/**
 * @author imssbora
 */
@Controller
public class Controlador {

   @RequestMapping("/")
   public String index(){
       return "intro.xhtml";
   }
}