/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webapp.basicwebapp.aspectos;

import com.webapp.basicwebapp.dao.BitacoraDao;
import java.util.Date;
import com.webapp.basicwebapp.pojos.AdministradorSistema;
import com.webapp.basicwebapp.pojos.Bitacora;
import com.webapp.basicwebapp.service.BitacoraService;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author T42719
 */
@Aspect
public class Aspecto {
    
    @Autowired(required = true)
    //private BitacoraService bitacoraService;
    private BitacoraDao bitacoraDao;
    /*
    @Before("@annotation(com.webapp.basicwebapp.aspectos.Loggable)")
    public void guardarLlamadaMetodo(JoinPoint pp){
        Bitacora bitacora = new Bitacora();
        bitacora.setAdministradorSistema(new AdministradorSistema("T42719"));
        bitacora.setAccion(pp.getSignature().toString());
        bitacora.setArgumentos(pp.getArgs().length > 0 ? pp.getArgs()[0].toString() : "");
        bitacora.setFecha(new Date());
        bitacoraDao.create(bitacora);
    }
    */
    /*
    @Around("execution(public * com.webapp.basicwebapp.service.GenericServiceImp.*(..))")
    //@Around("@annotation(com.webapp.basicwebapp.aspectos.Loggable)")
    public Object crearBitacoraServicios(ProceedingJoinPoint pp) throws Throwable{
        Bitacora bitacora = new Bitacora();
        bitacora.setAdministradorSistema(new AdministradorSistema("T42719"));
        bitacora.setAccion(pp.getSignature().toString());
        bitacora.setArgumentos(pp.getArgs().length > 0 ? pp.getArgs()[0].toString() : "");
        bitacora.setFecha(new Date());
        try {                  
            System.out.println("Antes: " + bitacora.getAccion());
            Object resultado = pp.proceed();
            System.out.println("Despues: " + bitacora.getAccion());
            bitacora.setResultado("OK");
            bitacoraDao.create(bitacora);
            return resultado;
        }
        catch(Throwable e) {
            //bitacoraDao.currentSession().getTransaction().rollback();
            bitacora.setResultado(e.getMessage());
            bitacoraDao.create(bitacora);
            System.out.println("Excepcion");
            throw e;
        }
    }
    */
    /*
    @AfterThrowing(pointcut="execution(public * com.webapp.basicwebapp.presentacion.VistaAdministrador.*(..))", throwing="e")
    public void crearExcepciones(JoinPoint pp, Exception e) throws Exception{
        Bitacora bitacora = crearBitacora(pp);
        bitacora.setResultado(e.getMessage());
        bitacoraDao.create(bitacora);
        System.out.println("Excepcion guardada");
        //e.printStackTrace();
    }
    */
    
    @AfterReturning("execution(public * com.webapp.basicwebapp.service.GenericServiceImp.*(..))")
    public void guardarResultado(JoinPoint pp){
        Bitacora bitacora = crearBitacora(pp);
        bitacora.setResultado("OK");
        bitacoraDao.create(bitacora);
        System.out.println("Bitacora creada");
    }
    public Bitacora crearBitacora(JoinPoint pp){
        Bitacora bitacora = new Bitacora();
        bitacora.setAdministradorSistema(new AdministradorSistema("T42719"));
        bitacora.setAccion(pp.getSignature().toString());
        bitacora.setArgumentos(pp.getArgs().length > 0 ? pp.getArgs()[0].toString() : "");
        bitacora.setFecha(new Date());
        return bitacora;
    }
}
