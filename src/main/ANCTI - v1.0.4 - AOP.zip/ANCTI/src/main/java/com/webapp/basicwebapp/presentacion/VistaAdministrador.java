/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webapp.basicwebapp.presentacion;

import com.webapp.basicwebapp.aspectos.Loggable;
import com.webapp.basicwebapp.pojos.AdministradorSistema;
import com.webapp.basicwebapp.service.AdministradorSistemaService;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.jsf.FacesContextUtils;

/**
 *
 * @author T42719
 */
//@ManagedBean(name = "admin")
//@ViewScoped
@Scope(value = "session")
@Component(value = "admin")
@ELBeanName(value = "admin")
@Join(path = "/index", to = "/intro.jsf")
public class VistaAdministrador implements Serializable{
    
    @Autowired(required = true)
    private AdministradorSistemaService adminService;
    private List<AdministradorSistema> administradores;
    private String clave;
    
    public String getClave() {return clave;}
    public void setClave(String clave) {this.clave = clave;}
    public List<AdministradorSistema> getAdministradores() {return administradores == null ? administradores = adminService.getAll() : administradores;}
    public void setAdministradores(List<AdministradorSistema> administradores) {this.administradores = administradores;}
    /*
    @PostConstruct
    private void init() {
        FacesContextUtils
            .getRequiredWebApplicationContext(FacesContext.getCurrentInstance())
            .getAutowireCapableBeanFactory().autowireBean(this);
    }
    */
    @Loggable
    public void registrarAdministrador() throws Exception{
        try{
            System.out.println("Iniciando registro");
            AdministradorSistema admin = new AdministradorSistema(clave);
            adminService.create(admin);
            administradores.add(admin);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Info", "Usuario " + clave + " se ha registrado como administrador."));
        }catch(Exception e){
            System.out.println("Excepcion en el registro");
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Ya existe el administrador " + clave + "."));
            System.out.println(e.getMessage());
            throw e;
        }
    }
    
    public void eliminarAdministrador(AdministradorSistema admin){
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Info", "Administrador " + admin.getClaveEmpleado() + " se ha eliminado"));
        adminService.remove(admin);
        administradores.remove(admin);
    }
}
