/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webapp.basicwebapp.service;

import com.webapp.basicwebapp.aspectos.Loggable;
import com.webapp.basicwebapp.dao.GenericDao;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author edgar
 */
@Loggable
@Service
public abstract class GenericServiceImp<E, K> 
        implements GenericService<E, K> {
 
    private GenericDao<E, K> genericDao;
 
    public GenericServiceImp(GenericDao<E,K> genericDao) {
        this.genericDao=genericDao;
    }
 
    public GenericServiceImp() {
    }
 
    @Override
    //@Loggable
    @Transactional(propagation = Propagation.REQUIRED)
    public void saveOrUpdate(E entity) {
        genericDao.saveOrUpdate(entity);
    }
 
    @Override
    //@Loggable
    @Transactional(propagation = Propagation.REQUIRED/*, readOnly = true*/)
    public List<E> getAll() {
        return genericDao.getAll();
    }
 
    @Override
    //@Loggable
    @Transactional(propagation = Propagation.REQUIRED/*, readOnly = true*/)
    public E find(K id) {
        return genericDao.find(id);
    }
 
    @Override
    //@Loggable
    @Transactional(propagation = Propagation.REQUIRED)
    public void create(E entity){
        genericDao.create(entity);
    }
 
    @Override
    //@Loggable
    @Transactional(propagation = Propagation.REQUIRED)
    public void update(E entity) {
        genericDao.update(entity);
    }
 
    @Override
    //@Loggable
    @Transactional(propagation = Propagation.REQUIRED)
    public void remove(E entity) {
        genericDao.remove(entity);
    }
}