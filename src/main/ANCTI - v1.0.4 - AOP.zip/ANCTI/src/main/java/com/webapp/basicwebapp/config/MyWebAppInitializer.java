/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webapp.basicwebapp.config;

/**
 *
 * @author edgar
 */
import com.sun.faces.config.ConfigureListener;
import javax.faces.webapp.FacesServlet;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

/**
 * @author imssbora
 */
public class MyWebAppInitializer
      extends AbstractAnnotationConfigDispatcherServletInitializer {

    @Override
    protected Class<?>[] getRootConfigClasses() {
       return new Class[] { AppConfig.class };
    }

    @Override
    protected Class<?>[] getServletConfigClasses() {
       return new Class[] { WebConfig.class };
    }

    @Override
    protected String[] getServletMappings() {
       return new String[] { "/" };
    }

    /* JSF */
    
    @Override
    public void onStartup(ServletContext servletContext)
            throws ServletException {

        /** Faces Servlet */
        ServletRegistration.Dynamic facesServlet = servletContext.addServlet("Faces Servlet", FacesServlet.class);
        facesServlet.setLoadOnStartup(1);
        facesServlet.addMapping("*.jsf");
        //facesServlet.addMapping("/javax.faces.resources/*");
        
        // Use JSF view templates saved as *.xhtml, for use with Facelets
        servletContext.setInitParameter("javax.faces.DEFAULT_SUFFIX", ".xhtml");
        // Enable special Facelets debug output during development
        servletContext.setInitParameter("javax.faces.PROJECT_STAGE",
                "Development");
        // Causes Facelets to refresh templates during development
        servletContext.setInitParameter("javax.faces.FACELETS_REFRESH_PERIOD",
                "1");
        // Declare Spring Security Facelets tag library
        servletContext.setInitParameter("javax.faces.FACELETS_LIBRARIES",
                "/WEB-INF/springsecurity.taglib.xml");

        servletContext.addListener(ConfigureListener.class);

        // Let the DispatcherServlet be registered
        super.onStartup(servletContext);
    }
}