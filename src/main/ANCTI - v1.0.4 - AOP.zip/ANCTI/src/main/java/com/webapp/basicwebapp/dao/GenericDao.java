/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webapp.basicwebapp.dao;

import java.util.List;
import org.hibernate.Session;

/**
 *
 * @author T42719
 */
public interface GenericDao<E,K> {
    public void create(E entity);
    public void saveOrUpdate(E entity) ;
    public void update(E entity) ;
    public void remove(E entity);
    public E find(K key);
    public List<E> getAll();
    public Session currentSession();
}